'use strict';

angular.module('inspinia')
  .controller('MainCtrl', function ($scope, $state) {
    var vm = this;
    vm.userName = 'HyperLocal Market';
    // vm.helloText = "asd";
    // console.log($state);
    // console.log($state.current);
    // console.log($state.current.data);
    // console.log($state.current.data.pageTitle);
    // if($state.current.data){
    	// var temp = $state;
    	// console.log($state);
    	// this.helloText = 'Welcome to the ' + temp.current.data.pageTitle;
    // }
    // this.descriptionText = 'It is an application skeleton for a typical AngularJS web app. You can use it to quickly bootstrap your angular webapp projects.';

  });
