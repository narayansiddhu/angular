'use strict';

angular.module('inspinia')
    .controller('departmentListCtrl', function ($scope, $state, departmentService, toaster, $stateParams) {
        var vm = this;

        // get user list api start here

        $scope.getDepartment = function () {
            departmentService.getDepartments().then(function (data) {
               
                $scope.departmentList = data;

            });
        }
        $scope.getDepartment();



        // Delete user api start here
        $scope.delete = function (id) {
            departmentService.deleteDepartment(id).then(function (data) {
                if (data.count == 1) {
                    toaster.success('Department Successfully Deleted!');
                    departmentService.getDepartments().then(function (data) {
                        $scope.departmentList = data;
                    });
                } else {
                    toaster.warning('Unable to delete');
                }
            });
        }
        // Delete user api end here

        $scope.edit = function (id) {
            $state.go('department.edit', {
                id: id
            });
        }

    });