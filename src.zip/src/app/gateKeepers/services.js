'use strict';

angular.module('inspinia').service('gateKeeperService', ['$q', '$http', 'configurationService', function ($q, $http, configurationService) {

    //returns a promise that resolves with customers if found,  
    //otherwise reject
    this.getUsers = function () {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/gateKeepers?filter[include]=appartment&filter[include]=flat&filter[include]=domesticStaff&filter[include]=block').success(function (data) {

            D.resolve(data);
        });
        return D.promise;
    }
    this.getAppartments = function () {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/appartments').success(function (data) {
            // console.log(data)
            D.resolve(data);
        });
        return D.promise;
    }
    this.getBlocksbyAppartment = function (id) {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/appartments/' + id + '/blockData').success(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }

    this.getFlatbyAppartment = function (id) {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/appartments/' + id + '/flatData').success(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }

    this.getDemosticStaff123 = function (id) {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/appartments/' + id + '/domesticStaff').success(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }
    this.getUserById = function (id) {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/gateKeepers/' + id + '?filter[include]=appartment&filter[include]=flat&filter[include]=department&filter[include]=domesticStaff&filter[include]=block&filter[include]=staff').success(function (data) {

            D.resolve(data);
        });
        return D.promise;
    }
    this.getflatsByBlock = function (id) {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/blocks/' + id + '/flatData').success(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }

    this.getDemesticStaffByFlats = function (id) {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/flats/' + id + '/domesticStaff').success(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }

    
    this.getFlatbyBlocks = function (id) {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/blocks/' + id + '/flat').success(function (data) {
            console.log(data);
            D.resolve(data);
        });
        return D.promise;
    }
    this.createUser = function (data) {
        var D = $q.defer()
        $http.post(configurationService.baseUrl() + '/gateKeepers', data).then(function (data) {

            D.resolve(data);
        }, function (data) {
            D.reject(data);
        });
        return D.promise;
    }
    this.getEvent = function (id) {

        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/merchants/' + id).success(function (data) {
            // console.log(data);

            D.resolve(data);
        }).error(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }
    this.deleteMerchant = function (id) {
        var D = $q.defer()
        $http.delete(configurationService.baseUrl() + '/gateKeepers/' + id).success(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }
    this.deleteKeeper = function (id) {
        var D = $q.defer()
        $http.delete(configurationService.baseUrl() + '/gateKeepers/' + id).success(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }
    
    this.updateUser = function (data) {
        var D = $q.defer()
        $http.put(configurationService.baseUrl() + '/gateKeepers', data).success(function (data) {
            D.resolve(data);
        }).error(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }
}]);
