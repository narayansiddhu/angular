'use strict';

angular.module('inspinia')
    .controller('gateKeepersCreateCtrl', ['$scope', '$state', 'NgMap', 'toaster', '$timeout', '$stateParams', '$rootScope', '$uibModal', '$log', 'FileUploader', 'configurationService', '$controller', 'gateKeeperService','ticketMastersService' ,function ($scope, $state, NgMap, toaster, $timeout, $stateParams, $rootScope, $uibModal, $log, FileUploader, configurationService, $controller, gateKeeperService,ticketMastersService) {
        var polygonInstance;
        var polygonData;
        var regionMap;
        var deliveryMap;
        $scope.merchantModel = {};
        $scope.merchantModel.address = {};
        $scope.event = {};
        $scope.showimage = true;
        $scope.imgobj = [];
        $scope.regEx = /^[0-9]{10,10}$/;
        $scope.users = {
            "visitorType": "",
            "visitorName": "",
            "visitorMobileNo": "",
            "visitedTo": "",
            "purpose": "",
            "image": "",
            "vehicleNo": "",
            "appartmentId": "",
            "departmentId": "",
            "staffId": "",
            "blockId": "",
            "flatId": "",
            "domesticStaffId": ""
          };
          
            $scope.allOpenDis=function(){
                $scope.visitorNameDis = false ;  
                $scope.bidOpeningDateDis = false ;  
                $scope.openingTimeDis = false ;  
                $scope.bidClosingDateDis = false ;  
                $scope.closeTimeDis = false ;  
                $scope.visitedToDis = false ;  
                $scope.vehicleNoDis = false ;  
                $scope.visitorMobileNoDis = false ;  
                $scope.purposeDis = false ;  
                $scope.vehicleTypeDis = false ;  
                $scope.appartmentIdDis = false ;  
                $scope.blockIdDis = false ;  
                $scope.flatIdDis = false ;  
                $scope.departmentIdDis = false ;  
                $scope.domesticStaffIdDis  = false ;  
                $scope.staffIdDis  = false ;   
            }
           
            $scope.allOpenDis() ;
            $scope.initialHide = false;
        var temp = [];
        var getCatName = {};
        $scope.tables = [{ id: 1, description: "Front" }, { id: 2, description: "Back" }];
        var fileurl = configurationService.baseUrl();
        $scope.visitorList=[{id:"staff",name:"Staff"},{id:"resident Staff",name:"Resident Staff"},{id:"guest",name:"Guest"},{id:"",name:"Select Type"}] ;
        $scope.users.visitorType= "" ;
        $scope.visitorToList=[{id:"flat",name:"flat"},{id:"office",name:"office"},{id:"",name:"Select Type"}] ;
        $scope.users.visitedTo= "" ;
        $scope.vechiclesList=[{id:'2 wheeler', name : '2 wheeler'},{id:'4 wheeler', name : '4 wheeler'},{id:'', name : 'Please select Vechile Type'}] ;
        $scope.users.vehicleType = '';
        $scope.disableSelected=false ;
        $scope.bidClosingDateDis=true ;
        $scope.closeTimeDis=true ;
        $scope.open1 = function (index, selected, size) {
            NgMap.getMap('billingmap').then(function (map) {
                regionMap = map;
                google.maps.event.trigger(regionMap, 'resize');
            });
            //  $scope.searchArea = "Burlington";
            $scope.Mapindex = index;
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: 'app/users/mapTemplate.html',
                controller: 'wareHouseMapCtrl',
                size: size

            });
            modalInstance.result.then(function (selectedItem) {
                $rootScope.pmapLatLngValues = selectedItem;
                $scope.selectedMap = selectedItem;
                latlngAddress($scope.selectedMap.data);
                $scope.merchantModel.address = selectedItem.message;
            }, function () {
                $log.info('Modal dismissed at: ' + new Date());
            });
        };
   

        $scope.addFamily = function (family) {
            //alert("addFamily")
            // $scope.finalAmount = "";
            $scope.users.family.push({ relation: "Select Relation", name: "", mobileNo: "" });
        };
        //  $scope.addFamily();

        $scope.removeFamily = function (index) {
            if ($scope.users.family.length) {
                $scope.users.family.splice(index, 1);
            }
        }
        // $scope.getUsersData = function () {
        //     gateKeeperService.getUsers().then(function (data) {

        //         console.log(data);
        //         $scope.users = data;
        //     });
        // }
        $scope.removeImg = function (index) {
            $scope.users.logo = "";

        }
        // Edit member api start here
        // $scope.getcategory = function (category) {
        //     dealService.getCategory(category).then(function (category) {
        //         $scope.listCategory = category.result.list;
        //         console.log(category.result);
        //         $scope.showDropDown = false;
        //         $scope.showMapBtn = true;

        //     });
        // }
        // $scope.getcategory();
        $scope.selectedType=function(){
            $scope.allOpenDis() ;
            if($scope.users.visitorType == 'resident Staff'){
                $scope.users.visitedTo= "flat" ;
                $scope.visitorNameDis=true ;
                $scope.visitedToDis=true ;
                $scope.staffIdDis =true ;
                $scope.departmentIdDis=true ;
                $scope.visitorMobileNoDis=true ;
            }else if($scope.users.visitorType == 'staff'){
                $scope.domesticStaffIdDis=true ;
                $scope.visitorNameDis=true ;
                $scope.visitorMobileNoDis=true ;
            }else if($scope.users.visitorType == 'guest'){
                $scope.staffIdDis =true ;
                $scope.departmentIdDis=true ;
                $scope.domesticStaffIdDis=true ;
            } 
        }
        $scope.visitedFun=function(){
            if($scope.users.visitorType == 'staff'){
               if($scope.users.visitedTo== "office"){
                $scope.blockIdDis=true ;
                $scope.users.blockId  ={blockName:"", id:"",appartmentId:""} ;
                $scope.flatIdDis=true ;
                $scope.users.flatId  = {"flatNo":"","flatSpcifications":"","noOfRooms":"","noOfBathrooms":"","facing":"","id":"","appartmentId":"","blockId":""};
               }else{
                $scope.blockIdDis=false ;
                $scope.flatIdDis=false ;
               }
            }
            if($scope.users.visitorType == 'guest'){
                if($scope.users.visitedTo== "office"){
                    $scope.blockIdDis=true ;
                    $scope.users.blockId  ={blockName:"Select Block", id:"",appartmentId:""} ;
                    $scope.flatIdDis=true ;
                    $scope.users.flatId  = {"flatNo":"Select Flat","flatSpcifications":"","noOfRooms":"","noOfBathrooms":"","facing":"","id":"","appartmentId":"","blockId":""};
                }else{
                    $scope.blockIdDis=false ;
                    $scope.flatIdDis=false ;
                   }
            } 

        }

        $scope.editEvent = function () {
            if ($state.current.breadcrumb.text == "Edit") {
                $scope.bidClosingDateDis=false ;
                $scope.closeTimeDis=false ;
                gateKeeperService.getUserById($stateParams.id).then(function (data) {
                    //$scope.getcategory();
                    console.log(data) ;
                    $scope.users = data ;
                    console.log($scope.users.appartmentId) ;
                    $scope.users.appartmentId =data.appartment ;
                    $scope.users.blockId =data.block ;
                    $scope.users.flatId =data.flat ;
                    $scope.users.departmentId =data.department ;
                    $scope.users.staffId =data.staff ;
                    $scope.users.domesticStaffId =data.domesticStaff ;
                    $scope.getAppartmentonchange($scope.users.appartmentId) ;
                    $scope.getFlatchange($scope.users.blockId) ;
                        $timeout(function(){
                            $scope.getStaffByDepchanged() ; 
                            $scope.getDemesticStaffByFlats();
                            $scope.selectedType() ;
                        },300);
                    var openingSplitTime=data.inTime.split('T') ;
                    var optingSplit1= openingSplitTime[1].split(':') ;
                    //Closeing time 
                    var closeSplitTime=data.outTime.split('T') ;
                    var closeSplit1= closeSplitTime[1].split(':') ;
                    $scope.openingTime =new Date(2018, 11, 24, Number(optingSplit1[0]), Number(optingSplit1[1]), 0, 0);
                    $scope.closeTime =new Date(2018, 11, 24, Number(closeSplit1[0]), Number(closeSplit1[1]), 0, 0);
                    $scope.bidOpeningDate =moment($scope.users.inTime).format("YYYY-MM-DD");
                    $scope.bidClosingDate =moment($scope.users.outTime).format("YYYY-MM-DD");
                    $scope.DPhotogetImage=true ;
                   
                });
            }
        }
        $scope.editEvent();
        // Edit member api end here
        // Logo Image upload 
        $scope.getAppartmentonchange = function (appartmentId) {
            console.log($scope.users.appartmentId);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            var appartmentid = $scope.users.appartmentId.id;
            gateKeeperService.getBlocksbyAppartment(appartmentid).then(function (data) {
                $scope.blocks = data;
                console.log(data);
            });
            ticketMastersService.getDepartmentbyAppartment(appartmentid).then(function (data) {
                $scope.deparMentList = data;
                console.log(data);
            });
        }

        $scope.getFlatchange = function (blockId) {
            console.log($scope.users.blockId);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            var blockId = $scope.users.blockId.id;
            gateKeeperService.getflatsByBlock(blockId).then(function (data) {
                $scope.flats = data;
                console.log(data);
            });

        }

        $scope.getDemesticStaffByFlats = function (flatId) {
            console.log($scope.users.flatId);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            var flatId = $scope.users.flatId.id;
            gateKeeperService.getDemesticStaffByFlats(flatId).then(function (data) {
                $scope.domesticStaffList = data;
                console.log(data);
            });

        }
        $scope.getAppartment = function () {
            //console.log($scope.users.appartmentId);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            // var appartmentid = $scope.users.appartmentId.id;
            gateKeeperService.getAppartments().then(function (data) {
                $scope.appartments = data;
                console.log(data);
            });

            
        }
        $scope.getAppartment();

       
        $scope.getStaffByDepchanged = function (departmentId1) {
            console.log($scope.users.departmentId);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            
            var departmentId = $scope.users.departmentId.id;
            ticketMastersService.getStaffByDepartment(departmentId).then(function (data) {
                    $scope.staffs = data;
                    console.log(data);
                    
                });

        }

        
        $scope.getBlocksOnChange = function (blockId) {
           // console.log($scope.users.blockId.id);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            var blockid = $scope.users.blockId.id;
            console.log(blockid);
            gateKeeperService.getFlatbyBlocks(blockid).then(function (data) {
                $scope.flats = data;
              //  console.log(data);
            });
        }

        $scope.baseurlimg = fileurl;

        // Driver address photo start Here
        $scope.driver_Photograph = function () {
            var img_div = angular.element(document.querySelector('#driver_Photograph'));
            img_div.addClass('remove_img');
        }

        var driverPhoto = $scope.driverPhoto = new FileUploader({
            scope: $scope,
            url: fileurl + '/containers/users/upload',
            formData: [
                { key: 'value' }
            ]
        });

        driverPhoto.onSuccessItem = function (item, response, status, headers) {
            $scope.driverAddPhoto = response;
            if ($scope.driverAddPhoto.result.files.file[0].name == undefined) {
                toastr.warning('Error : Problem in upload image');
            } else {
                $scope.users.image = '/containers/users/download/' + $scope.driverAddPhoto.result.files.file[0].name;
                $scope.DPhotogetImage = true;
              
            }
        };
        // image upload end here

        // End Image 
        $scope.save = function (merchant) {
            var error = 0;
            if (error == 0) {
                if ($state.current.breadcrumb.text == "Create") {
                   
                  $scope.users.appartmentId=$scope.users.appartmentId.id ;
                  $scope.users.blockId =$scope.users.blockId.id ;
                  $scope.users.flatId =$scope.users.flatId.id ;

                  $scope.users.departmentId =$scope.users.departmentId.id ;
                  $scope.users.staffId = $scope.users.staffId.id ;
                  $scope.users.domesticStaffId = $scope.users.domesticStaffId.id ;

                  $scope.users.inTime = $scope.bidOpeningDate+'T'+moment($scope.openingTime).format('HH:mm')+':00.000Z' ;
                  $scope.users.outTime = $scope.bidClosingDate+'T'+moment($scope.closeTime).format('HH:mm')+':00.000Z' ;
                  console.log( $scope.users) ;
                  gateKeeperService.createUser($scope.users).then(function (data) {

                        $state.go('gateKeepers');
                        toaster.pop({
                            type: 'success',
                            title: 'User Created Successfully',
                            showCloseButton: true
                        });
                    })
                } else {

                    $scope.users.appartmentId=$scope.users.appartmentId.id ;
                    $scope.users.blockId =$scope.users.blockId.id ;
                    $scope.users.flatId =$scope.users.flatId.id ;

                    $scope.users.departmentId =$scope.users.departmentId.id ;
                    $scope.users.staffId = $scope.users.staffId.id ;
                    $scope.users.domesticStaffId = $scope.users.domesticStaffId.id ;

                    $scope.users.inTime = $scope.bidOpeningDate+'T'+moment($scope.openingTime).format('HH:mm')+':00.000Z' ;
                    $scope.users.outTime = $scope.bidClosingDate+'T'+moment($scope.closeTime).format('HH:mm')+':00.000Z' ;
                 
                    delete $scope.users.appartment ;
                    delete $scope.users.block ;
                    delete $scope.users.flat ;

                    delete $scope.users.department ;
                    delete $scope.users.staff ;
                    delete $scope.users.domesticStaff ;


                    gateKeeperService.updateUser($scope.users).then(function (data) {
                     
                        $state.go('gateKeepers');
                        toaster.pop({
                            type: 'success',
                            title: 'User Updated Successfully',
                            showCloseButton: true
                        });
                    })
                }
            }
        }
    }]);