'use strict';

angular.module('inspinia')
    .controller('gateKeepersListCtrl', function ($scope, $state, gateKeeperService, toaster, $stateParams) {
        var vm = this;

        // get user list api start here
        $scope.getUsersData = function () {
            gateKeeperService.getUsers().then(function (data) {
                console.log(data);
                $scope.users = data;
            });
        }
        $scope.getUsersData();
        // get user list api end here

        // Delete user api start here
        $scope.delete = function (id) {
            gateKeeperService.deleteKeeper(id).then(function (data) {
               
                

                if (data.count == 1) {
                    toaster.success('User Successfully Deleted!');
                    $scope.getUsersData();
                } else {
                    toaster.warning('Unable to delete');
                }
            })
        }
        // Delete user api end here

        $scope.edit = function (id) {

            // merchantService.getEvent(id).then(function(data){
            //    $scope.merchant = data; 
            //    console.log($scope.merchant);
            // });

            $state.go('gateKeepers.edit', {
                id: id
            });
        }
    });