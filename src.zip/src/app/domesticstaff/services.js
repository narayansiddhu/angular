'use strict';

angular.module('inspinia').service('domesticstaffService', ['$q', '$http', 'configurationService', function ($q, $http, configurationService) {

    //returns a promise that resolves with customers if found, 
    //otherwise reject


    this.getList = function () {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/domesticStaffs?filter[include]=appartment&filter[include]=department&filter[include]=block&filter[include]=flat').success(function (data) {
           // console.log(data)
            D.resolve(data);
        });
        return D.promise;
    }

    this.getAppartments = function () {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/appartments').success(function (data) {
            // console.log(data)
            D.resolve(data);
        });
        return D.promise;
    }
    this.getBlocksbyAppartment = function (id) {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/appartments/' + id + '/department').success(function (data) {

            D.resolve(data);
        });
        return D.promise;
    }


    this.createStaffs = function (data) {
        var D = $q.defer()
        $http.post(configurationService.baseUrl() + '/domesticStaffs', data).then(function (data) {
            D.resolve(data);
        }, function (data) {
            D.reject(data);
        });
        return D.promise;
    }

    this.getStaffbyId = function (id) {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/domesticStaffs/' + id+'?filter[include]=appartment&filter[include]=department&filter[include]=block&filter[include]=flat').success(function (data) {
           
            D.resolve(data);
        }).error(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }
    this.deleteStaff = function (id) {
        var D = $q.defer()
        $http.delete(configurationService.baseUrl() + '/domesticStaffs/' + id).success(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }
    this.updateStaffs = function (data) {
        var D = $q.defer()
        $http.put(configurationService.baseUrl() + '/domesticStaffs', data).success(function (data) {
            D.resolve(data);
        }).error(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }
}]);
