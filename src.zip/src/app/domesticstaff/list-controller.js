'use strict';

angular.module('inspinia')
    .controller('domesticstaffListCtrl', function ($scope, $state, FileUploader, domesticstaffService, toaster, $stateParams) {
        var vm = this;

        // get user list api start here
        // $scope.exportToExcel = function () {
        //     var blob = new Blob([document.getElementById('tableToExport').innerHTML], {
        //         type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"
        //     });
        //     saveAs(blob, "UsersList.xls");
        // };
        $scope.getstaffList = function () {
            domesticstaffService.getList().then(function (data) {
                $scope.staff = data;
               // console.log($scope.flats);
                //  console.log($scope.appartment);
            });
        }
        $scope.getstaffList();

        // get user list api end here

        /********************Excel start  ***********************/
        $scope.exportToExcel = function () {
            alasql('SELECT * INTO XLSX("myinquires.xlsx",{headers:true}) \
                    FROM HTML("#tableToExport",{headers:true})');
        };
        /********************Excel end  ***********************/

        // Delete user api start here
    
        $scope.delete = function (id) {
            domesticstaffService.deleteStaff(id).then(function (data) {
                if (data.count == 1) {
                    domesticstaffService.getList().then(function (data) {
                        $scope.staff = data;
                       // console.log($scope.flats);
                        //  console.log($scope.appartment);
                    });
                    toaster.success('Flat Successfully Deleted!');
                     

                } else {
                    toaster.warning('Unable to delete');
                }
            })
        }
        //   $scope.delete();
        // Delete user api end here

        $scope.edit = function (id) {
            $state.go('domesticstaff.edit', {
                id: id
            });
        }
    });