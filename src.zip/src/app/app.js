'use strict';

angular.module('inspinia', ['ngAnimate', 'angularFileUpload', 'jcs-autoValidate', 'ngCookies', 'ngTouch', 'ngSanitize', 'ngResource', 'ui.router', 'ui.bootstrap', 'datatables', 'ui.footable', 'ngMap', 'vsGoogleAutocomplete', 'toaster', 'ngDraggable', 'ui.router.breadcrumbs', '720kb.datepicker', 'ngToast', 'schemaForm', 'angular.filter', 'ui.bootstrap.datetimepicker', 'angular.filter', 'ui.select', 'pascalprecht.translate', 'ngSchemaFormFile', 'ngMessages', 'ngMaterial', 'sc.select', 'colorpicker.module', 'ui.calendar', 'ui.toggle', 'ngCsvImport', 'schemaForm-datepicker', 'schemaForm-timepicker', 'schemaForm-datetimepicker', 'pascalprecht.translate', 'ngSchemaFormFile', 'ngPrint', 'chart.js'])

    .service('APIInterceptor', function ($cookieStore) {
        var service = this;
        service.request = function (config) {
            if ($cookieStore.get('loginAccess')) {
                config.headers.Authorization = $cookieStore.get('loginAccess').id;
            }
            return config;
        }
    })
    .run(function ($rootScope, $state, $cookieStore, NgMap) {

        NgMap.getMap().then(function (map) {
            $rootScope.map = map;
        });

        $rootScope.$on('$locationChangeSuccess', function () {
            $rootScope.$state = $state;

            if ($cookieStore.get('loginAccess') == undefined) {
                $rootScope.hideView = true;
                $state.go('login');
            }
        });
        $rootScope.cancel = function () {
            window.history.back();
        };
        $rootScope.redirectSub = '';
        $rootScope.mapLatLngValues = {
            lat: '',
            lng: '',
            data: {},
            message: ''
        };
        $rootScope.tempRoute = {};
        $rootScope.selectedMaparea = {};
    })
    .config(function ($stateProvider, $urlRouterProvider, $httpProvider, breadcrumbsProvider, $translateProvider, $mdDateLocaleProvider, ChartJsProvider) {
        ChartJsProvider.setOptions({ colors: ['#803690', '#00ADF9', '#DCDCDC', '#46BFBD', '#FDB45C', '#949FB1', '#4D5360'] });

        $mdDateLocaleProvider.formatDate = function (date) {
            return moment(date).format('DD-MM-YYYY');
        };

        $mdDateLocaleProvider.parseDate = function (dateString) {
            var m = moment(dateString, 'DD-MM-YYYY', true);
            return m.isValid() ? m.toDate() : new Date(NaN);
        };

        $translateProvider.translations('en', {
            'modules.upload.dndNotSupported': 'Drag n drop not surpported by your browser',
            'modules.attribute.fields.required.caption': 'Required',
            'modules.upload.descriptionMultifile': 'Drop your file(s) here',
            'buttons.add': 'Open file browser',
            'modules.upload.field.filename': 'Filename',
            'modules.upload.field.preview': 'Preview',
            'modules.upload.multiFileUpload': 'Multifile upload',
            'modules.upload.field.progress': 'Progress',
            'buttons.upload': 'Upload',
            'modules.upload.descriptionSinglefile': '',
        });
        $translateProvider.preferredLanguage('en');
        $stateProvider.state('login', {
            title: 'B-Buzz',
            url: "/login",
            templateUrl: "app/login/index.html",
            controller: 'loginCtrl'
        })
            .state('logout', {
                url: "/logout",
                controller: 'logoutCtrl',
                templateUrl: "app/logout/index.html"
            })
            .state('dashboard', {
                url: "/dashboard",
                views: {
                    "@": {
                        templateUrl: "app/dashboard/view.html",
                        controller: 'adminDashboardCtrl as adminDashboard'
                    }
                },
                title: 'Welcome To Admin Dashboard ',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Dashboard',
                    stateName: 'dashboard'
                }
            })
            // members states start here
            .state('appartment', {
                url: "/appartment",
                views: {
                    "@": {
                        templateUrl: "app/appartment/list.html",
                        controller: 'AppartmentListCtrl as appartmentList'
                    }
                },
                title: 'Appartment',
                breadcrumb: {
                    class: 'highlight',
                    text: 'List',
                    stateName: 'appartment'
                }
            })
            .state('appartment.create', {
                url: "/create",
                views: {
                    "@": {
                        templateUrl: "app/appartment/create.html",
                        controller: 'appartmentCreateCtrl as appartmentCreate'
                    }
                },
                title: 'Appartment Create',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Create',
                    stateName: 'appartment.create'
                }
            })
            .state('appartment.edit', {
                url: "/edit/:id",
                views: {
                    "@": {
                        templateUrl: "app/appartment/create.html",
                        controller: 'appartmentCreateCtrl as appartmentCreate'
                    }
                },
                title: 'Appartment Edit',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Edit',
                    stateName: 'appartment.edit'
                }
            })
            // members states start here

            // Flat states start here
            .state('flat', {
                url: "/flat",
                views: {
                    "@": {
                        templateUrl: "app/flat/list.html",
                        controller: 'flatListCtrl as flatList'
                    }
                },
                title: 'Flat',
                breadcrumb: {
                    class: 'highlight',
                    text: 'List',
                    stateName: 'flat'
                }
            })
            .state('flat.create', {
                url: "/create",
                views: {
                    "@": {
                        templateUrl: "app/flat/create.html",
                        controller: 'flatCreateCtrl as flatCreate'
                    }
                },
                title: 'Flat Create',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Flat',
                    stateName: 'flat.create'
                }
            })
            .state('flat.edit', {
                url: "/edit/:id",
                views: {
                    "@": {
                        templateUrl: "app/flat/create.html",
                        controller: 'flatCreateCtrl as flatCreate'
                    }
                },
                title: 'Flat Edit',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Edit',
                    stateName: 'flat.edit'
                }
            })
            // block states start here
            .state('block', {
                url: "/block",
                views: {
                    "@": {
                        templateUrl: "app/block/list.html",
                        controller: 'blockListCtrl as blockList'
                    }
                },
                title: 'Block',
                breadcrumb: {
                    class: 'highlight',
                    text: 'List',
                    stateName: 'block'
                }
            })
            .state('block.create', {
                url: "/create",
                views: {
                    "@": {
                        templateUrl: "app/block/create.html",
                        controller: 'blockCreateCtrl as blockCreate'
                    }
                },
                title: 'Block Create',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Create',
                    stateName: 'block.create'
                }
            })
            .state('block.edit', {
                url: "/edit/:id",
                views: {
                    "@": {
                        templateUrl: "app/block/create.html",
                        controller: 'blockCreateCtrl as blockCreate'
                    }
                },
                title: 'Block Edit',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Edit',
                    stateName: 'block.edit'
                }
            })
            //St0aff starts here
            .state('staff', {
                url: "/staff",
                views: {
                    "@": {
                        templateUrl: "app/staff/list.html",
                        controller: 'staffListCtrl as staffList'
                    }
                },
                title: 'Staff',
                breadcrumb: {
                    class: 'highlight',
                    text: 'List',
                    stateName: 'staff'
                }
            })
            .state('staff.create', {
                url: "/create",
                views: {
                    "@": {
                        templateUrl: "app/staff/create.html",
                        controller: 'staffCreateCtrl as staffCreate'
                    }
                },
                title: 'Staff Create',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Create',
                    stateName: 'staff.create'
                }
            })
            .state('staff.edit', {
                url: "/edit/:id",
                views: {
                    "@": {
                        templateUrl: "app/staff/create.html",
                        controller: 'staffCreateCtrl as staffCreate'
                    }
                },
                title: 'Staff Edit',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Edit',
                    stateName: 'staff.edit'
                }
            }) 
                // vendor starts here
                .state('vendor', {
                    url: "/vendor",
                    views: {
                        "@": {
                            templateUrl: "app/vendor/list.html",
                            controller: 'vendorListCtrl as vendorList'
                        }
                    },
                    title: 'Vendor',
                    breadcrumb: {
                        class: 'highlight',
                        text: 'List',
                        stateName: 'vendor'
                    }
                })
                .state('vendor.create', {
                    url: "/create",
                    views: {
                        "@": {
                            templateUrl: "app/vendor/create.html",
                            controller: 'vendorCreateCtrl as vendorCreate'
                        }
                    },
                    title: 'Vendor Create',
                    breadcrumb: {
                        class: 'highlight',
                        text: 'Create',
                        stateName: 'vendor.create'
                    }
                })
                .state('vendor.edit', {
                    url: "/edit/:id",
                    views: {
                        "@": {
                            templateUrl: "app/vendor/create.html",
                            controller: 'vendorCreateCtrl as vendorCreate'
                        }
                    },
                    title: 'Vendor Edit',
                    breadcrumb: {
                        class: 'highlight',
                        text: 'Edit',
                        stateName: 'vendor.edit'
                    }
                })
                           // Bills starts here
                           .state('bills', {
                            url: "/bills",
                            views: {
                                "@": {
                                    templateUrl: "app/bills/list.html",
                                    controller: 'billsListCtrl as billsList'
                                }
                            },
                            title: 'Bills',
                            breadcrumb: {
                                class: 'highlight',
                                text: 'List',
                                stateName: 'bills'
                            }
                        })
                        .state('bills.create', {
                            url: "/create",
                            views: {
                                "@": {
                                    templateUrl: "app/bills/create.html",
                                    controller: 'billsCreateCtrl as billsCreate'
                                }
                            },
                            title: 'Bill Create',
                            breadcrumb: {
                                class: 'highlight',
                                text: 'Create',
                                stateName: 'bills.create'
                            }
                        })
                        .state('bills.edit', {
                            url: "/edit/:id",
                            views: {
                                "@": {
                                    templateUrl: "app/bills/create.html",
                                    controller: 'billsCreateCtrl as billsCreate'
                                }
                            },
                            title: 'Bill Edit',
                            breadcrumb: {
                                class: 'highlight',
                                text: 'Edit',
                                stateName: 'bills.edit'
                            }
                        })
                         //Facilities starts here
                         .state('facilities', {
                            url: "/facilities",
                            views: {
                                "@": {
                                    templateUrl: "app/facilities/list.html",
                                    controller: 'facilitiesListCtrl as facilitiesList'
                                }
                            },
                            title: 'Facilities',
                            breadcrumb: {
                                class: 'highlight',
                                text: 'List',
                                stateName: 'facilities'
                            }
                        })
                        .state('facilities.create', {
                            url: "/create",
                            views: {
                                "@": {
                                    templateUrl: "app/facilities/create.html",
                                    controller: 'facilitiesCreateCtrl as facilitiesCreate'
                                }
                            },
                            title: 'Facilities Create',
                            breadcrumb: {
                                class: 'highlight',
                                text: 'Create',
                                stateName: 'facilities.create'
                            }
                        })
                        .state('facilities.edit', {
                            url: "/edit/:id",
                            views: {
                                "@": {
                                    templateUrl: "app/facilities/create.html",
                                    controller: 'facilitiesCreateCtrl as facilitiesCreate'
                                }
                            },
                            title: 'Facilities Edit',
                            breadcrumb: {
                                class: 'highlight',
                                text: 'Edit',
                                stateName: 'facilities.edit'
                            }
                        })
                        //Event starts here
                        .state('events', {
                            url: "/events",
                            views: {
                                "@": {
                                    templateUrl: "app/events/list.html",
                                    controller: 'eventsListCtrl as eventsList'
                                }
                            },
                            title: 'Facilities',
                            breadcrumb: {
                                class: 'highlight',
                                text: 'List',
                                stateName: 'events'
                            }
                        })
                        .state('events.create', {
                            url: "/create",
                            views: {
                                "@": {
                                    templateUrl: "app/events/create.html",
                                    controller: 'eventsCreateCtrl as eventsCreate'
                                }
                            },
                            title: 'Facilities Create',
                            breadcrumb: {
                                class: 'highlight',
                                text: 'Create',
                                stateName: 'events.create'
                            }
                        })
                        .state('events.edit', {
                            url: "/edit/:id",
                            views: {
                                "@": {
                                    templateUrl: "app/events/create.html",
                                    controller: 'eventsCreateCtrl as eventsCreate'
                                }
                            },
                            title: 'Facilities Edit',
                            breadcrumb: {
                                class: 'highlight',
                                text: 'Edit',
                                stateName: 'events.edit'
                            }
                        })
                        //Payments starts here
                        .state('payments', {
                            url: "/payments",
                            views: {
                                "@": {
                                    templateUrl: "app/payments/list.html",
                                    controller: 'paymentsListCtrl as paymentsList'
                                }
                            },
                            title: 'payments',
                            breadcrumb: {
                                class: 'highlight',
                                text: 'List',
                                stateName: 'payments'
                            }
                        })
                        .state('payments.create', {
                            url: "/create",
                            views: {
                                "@": {
                                    templateUrl: "app/payments/create.html",
                                    controller: 'paymentsCreateCtrl as paymentsCreate'
                                }
                            },
                            title: 'payment Create',
                            breadcrumb: {
                                class: 'highlight',
                                text: 'Create',
                                stateName: 'payments.create'
                            }
                        })
                        .state('payments.edit', {
                            url: "/edit/:id",
                            views: {
                                "@": {
                                    templateUrl: "app/payments/create.html",
                                    controller: 'paymentsCreateCtrl as paymentsCreate'
                                }
                            },
                            title: 'payment Edit',
                            breadcrumb: {
                                class: 'highlight',
                                text: 'Edit',
                                stateName: 'payments.edit'
                            }
                        })
                   //Domesticstaff starts here
                   .state('domesticstaff', {
                    url: "/domesticstaff",
                    views: {
                        "@": {
                            templateUrl: "app/domesticstaff/list.html",
                            controller: 'domesticstaffListCtrl as domesticstaffList'
                        }
                    },
                    title: 'Resident Staff',
                    breadcrumb: {
                        class: 'highlight',
                        text: 'List',
                        stateName: 'domesticstaff'
                    }
                })
                .state('domesticstaff.create', {
                    url: "/create",
                    views: {
                        "@": {
                            templateUrl: "app/domesticstaff/create.html",
                            controller: 'domesticstaffCreateCtrl as staffCreate'
                        }
                    },
                    title: 'Resident Staff Create',
                    breadcrumb: {
                        class: 'highlight',
                        text: 'Create',
                        stateName: 'domesticstaff.create'
                    }
                })
                .state('domesticstaff.edit', {
                    url: "/edit/:id",
                    views: {
                        "@": {
                            templateUrl: "app/domesticstaff/create.html",
                            controller: 'domesticstaffCreateCtrl as domesticstaffCreate'
                        }
                    },
                    title: 'Resident Staff Edit',
                    breadcrumb: {
                        class: 'highlight',
                        text: 'Edit',
                        stateName: 'domesticstaff.edit'
                    }
                })
            // vehicle starts here
            .state('vehicle', {
                url: "/vehicle",
                views: {
                    "@": {
                        templateUrl: "app/vehicle/list.html",
                        controller: 'vehicleListCtrl as vehicleList'
                    }
                },
                title: 'Vehicle',
                breadcrumb: {
                    class: 'highlight',
                    text: 'List',
                    stateName: 'vehicle'
                }
            })
            .state('vehicle.create', {
                url: "/create",
                views: {
                    "@": {
                        templateUrl: "app/vehicle/create.html",
                        controller: 'vehicleCreateCtrl as vehicleCreate'
                    }
                },
                title: 'vehicle Create',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Create',
                    stateName: 'vehicle.create'
                }
            })
            .state('vehicle.edit', {
                url: "/edit/:id",
                views: {
                    "@": {
                        templateUrl: "app/vehicle/create.html",
                        controller: 'vehicleCreateCtrl as vehicleCreate'
                    }
                },
                title: 'vehicle Edit',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Edit',
                    stateName: 'vehicle.edit'
                }
            })
            //  end here

            // department
            .state('department', {
                url: "/department",
                views: {
                    "@": {
                        templateUrl: "app/department/list.html",
                        controller: 'departmentListCtrl'
                    }
                },
                title: 'Department',
                breadcrumb: {
                    class: 'highlight',
                    text: 'List',
                    stateName: 'department'
                }
            })
            .state('department.create', {
                url: "/create",
                views: {
                    "@": {
                        templateUrl: "app/department/create.html",
                        controller: 'departmentCreateCtrl'
                    }
                },
                title: 'Department Create',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Department',
                    stateName: 'department.create'
                }
            })
            .state('department.edit', {
                url: "/edit/:id",
                views: {
                    "@": {
                        templateUrl: "app/department/create.html",
                        controller: 'departmentCreateCtrl'
                    }
                },
                title: 'Department Edit',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Edit',
                    stateName: 'department.edit'
                }
            })
            // END 
            // equipments
            .state('equipments', {
                url: "/equipments",
                views: {
                    "@": {
                        templateUrl: "app/equipments/list.html",
                        controller: 'equipmentsListCtrl'
                    }
                },
                title: 'Equipments',
                breadcrumb: {
                    class: 'highlight',
                    text: 'List',
                    stateName: 'equipments'
                }
            })
            .state('equipments.create', {
                url: "/create",
                views: {
                    "@": {
                        templateUrl: "app/equipments/create.html",
                        controller: 'equipmentsCreateCtrl'
                    }
                },
                title: 'Equipments Create',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Equipments',
                    stateName: 'equipments.create'
                }
            })
            .state('equipments.edit', {
                url: "/edit/:id",
                views: {
                    "@": {
                        templateUrl: "app/equipments/create.html",
                        controller: 'equipmentsCreateCtrl'
                    }
                },
                title: 'Equipments Edit',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Edit',
                    stateName: 'equipments.edit'
                }
            }) 
            // END 
            // users states start here
            .state('users', {
                url: "/users",
                views: {
                    "@": {
                        templateUrl: "app/users/list.html",
                        controller: 'usersListCtrl as usersList'
                    }
                },
                title: 'Users',
                breadcrumb: {
                    class: 'highlight',
                    text: 'List',
                    stateName: 'users'
                }
            })
            .state('users.create', {
                url: "/create",
                views: {
                    "@": {
                        templateUrl: "app/users/create.html",
                        controller: 'usersCreateCtrl as usersCreate'
                    }
                },
                title: 'Users Create',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Create',
                    stateName: 'users.create'
                }
            })
            .state('users.edit', {

                url: "/edit/:id",
                views: {
                    "@": {
                        templateUrl: "app/users/create.html",
                        controller: 'usersCreateCtrl as usersCreate'
                    }
                },
                title: 'Users Edit',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Edit',
                    stateName: 'users.edit'
                }
            })
            // members states start here
            // helpcenter  Rouuting Start Here

            .state('helpcenterCreate.create', {
                url: "/create",
                views: {
                    "@": {
                        templateUrl: "app/helpcenter/create.html",
                        controller: 'helpcenterCreateCtrl as helpcenterCreate'
                    }
                },
                title: 'Help Center',
                breadcrumb: {
                    class: 'highlight',
                    text: 'create',
                    stateName: 'helpcenterCreate.create'
                }
            })
            .state('ticketMaster', {
                url: "/ticketMaster",
                views: {
                    "@": {
                        templateUrl: "app/ticketMaster/list.html",
                        controller: 'ticketMasterListCtrl'
                    }
                },
                title: 'Ticket Master',
                breadcrumb: {
                    class: 'highlight',
                    text: 'List',
                    stateName: 'ticketMaster'
                }
            })
            .state('ticketMaster.create', {
                url: "/create",
                views: {
                    "@": {
                        templateUrl: "app/ticketMaster/create.html",
                        controller: 'ticketMasterCreateCtrl'
                    }
                },
                title: 'Ticket Master Create',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Create',
                    stateName: 'ticketMaster.create'
                }
            })
            .state('ticketMaster.edit', {
                url: "/edit/:id",
                views: {
                    "@": {
                        templateUrl: "app/ticketMaster/create.html",
                        controller: 'ticketMasterCreateCtrl'
                    }
                },
                title: 'Ticket Master Edit',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Edit',
                    stateName: 'domesticStaff.edit'
                }
            }) 
            .state('gateKeepers', {
                url: "/gateKeepers",
                views: {
                    "@": {
                        templateUrl: "app/gateKeepers/list.html",
                        controller: 'gateKeepersListCtrl'
                    }
                },
                title: 'Gate Keepers Master',
                breadcrumb: {
                    class: 'highlight',
                    text: 'List',
                    stateName: 'gateKeepers'
                }
            })
            .state('gateKeepers.create', {
                url: "/create",
                views: {
                    "@": {
                        templateUrl: "app/gateKeepers/create.html",
                        controller: 'gateKeepersCreateCtrl'
                    }
                },
                title: 'Gate Keeper Create',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Create',
                    stateName: 'gateKeepers.create'
                }
            })
            .state('gateKeepers.edit', {
                url: "/edit/:id",
                views: {
                    "@": {
                        templateUrl: "app/gateKeepers/create.html",
                        controller: 'gateKeepersCreateCtrl'
                    }
                },
                title: 'Gate Keepers Edit',
                breadcrumb: {
                    class: 'highlight',
                    text: 'Edit',
                    stateName: 'gateKeepers.edit'
                }
            })
        //Advertisement Rouuting End HereÓ
        $urlRouterProvider.otherwise('dashboard');
        $httpProvider.interceptors.push('APIInterceptor');
    })