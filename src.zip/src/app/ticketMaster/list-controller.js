'use strict';

angular.module('inspinia')
    .controller('ticketMasterListCtrl', function ($scope, $state, ticketMastersService, toaster, $stateParams) {
        var vm = this;

        // get user list api start here
        $scope.ticketMastersService = function () {
            ticketMastersService.getList().then(function (data) {
                console.log(data);
                $scope.ticketMaster = data;
            });
        }
        $scope.ticketMastersService();
        // get user list api end here
        // Delete user api start here
        $scope.delete = function (id) {
            ticketMastersService.deleteticketMaster(id).then(function (data) {
              //  var merchantCount = data.count
                if (data) {
                    ticketMastersService.getList().then(function (data) {
                        console.log(data);
                        $scope.ticketMaster = data;
                    });
                    toaster.success('Ticket Master Successfully Deleted!');
                    
                } else {
                    toaster.warning('Unable to delete');
                }
            })
        }
      
        $scope.takenTime=function(obj){
            console.log(obj) ;
            var findStart= _.findIndex(obj,function(x){
                return x.status === 1001 ;
            });
            var startTime = obj[findStart].timestamp ;
            var findEnd= _.findIndex(obj,function(x){
                return x.status === 1002 ;
            });
            var endTime = obj[findEnd].timestamp ;
           
            console.log(startTime,endTime);
           //"04/09/2013 15:12:00"
            var now  =  moment(endTime).format("DD/MM/YYYY HH:mm:ss") ;
            console.log(now) ;
            //"02/09/2013 14:20:30";
            var then = moment(startTime).format("DD/MM/YYYY HH:mm:ss") ; 
            console.log(then,now) ;
            
            var ms = moment(now,"DD/MM/YYYY HH:mm:ss").diff(moment(then,"DD/MM/YYYY HH:mm:ss"));
            var timeInMilliSeconds = moment.duration(ms);
            
            // var s = d.format("hh:mm:ss");

            // return s;
           return convertMS( timeInMilliSeconds )
        }

        function convertMS( milliseconds ) {
            var day, hour, minute, seconds;
            seconds = Math.floor(milliseconds / 1000);
            minute = Math.floor(seconds / 60);
            seconds = seconds % 60;
            hour = Math.floor(minute / 60);
            minute = minute % 60;
            day = Math.floor(hour / 24);
            hour = hour % 24;
            return {
                day: day,
                hour: hour,
                minute: minute,
                seconds: seconds
            };
        }

        $scope.edit = function (id) {

            // merchantService.getEvent(id).then(function(data){
            //    $scope.merchant = data; 
            //    console.log($scope.merchant);
            // });

            $state.go('ticketMaster.edit', {
                id: id
            });
        }
    });