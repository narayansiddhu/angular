'use strict';
angular.module('inspinia')
    .controller('ticketMasterCreateCtrl', ['$scope', '$state', 'NgMap', 'toaster', '$timeout', '$stateParams', '$rootScope', '$uibModal', '$log', 'FileUploader', 'configurationService', '$controller', 'ticketMastersService','usersService','$cookieStore', function ($scope, $state, NgMap, toaster, $timeout, $stateParams, $rootScope, $uibModal, $log, FileUploader, configurationService, $controller, ticketMastersService,usersService,$cookieStore) {
        var polygonInstance;
        var polygonData;
        var regionMap;
        var deliveryMap;
        $scope.merchantModel = {};
        $scope.ticketMaster={} ;
        $scope.merchantModel.address = {};
        $scope.event = {};
        $scope.event.showStatus = false;
        $scope.showimage = true;
        $scope.imgobj = [];
        $scope.regEx = /^[0-9]{10,10}$/;
        $scope.users = {};
        $scope.initialHide = false;
        var temp = [];
        var getCatName = {};
        $scope.tables = [{ id: 1, description: "Front" }, { id: 2, description: "Back" }];
        $scope.statusList = [{ id: 1001, name: "Not resolved" }, { id: 1002, name: "Resolved" },{ id: 1003, name: "Assigned" },{ id: 1004, name: "Progress" }];
       // $scope.event.showStatus=false ;
        $scope.getAppartment = function () {
            usersService.getAppartments().then(function (data) {
                $scope.appartments = data;
                console.log(data);
            });
        }
        $scope.getAppartment();
        $scope.getAppartmentonchange = function (appartmentId) {
            console.log($scope.ticketMaster.appartmentId);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            var appartmentid = $scope.ticketMaster.appartmentId.id;
            // usersService.getFlatbyAppartment(appartmentid).then(function (data) {
            //     $scope.flats = data;
            //     console.log(data);
            // });
            usersService.getBlocksbyAppartment(appartmentid).then(function (data) {
                $scope.blocks = data;
                console.log(data);
            });
            // ticketMastersService.getStaffbyAppartment(appartmentid).then(function (data) {
            //     $scope.staffs = data;
            //     console.log(data);
            // });
            ticketMastersService.getDepartmentbyAppartment(appartmentid).then(function (data) {
                $scope.deparMentList = data;
                console.log(data);
            });
        }
        $scope.getFlatchange = function (blockId) {
            console.log($scope.ticketMaster.blockId);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            var blockId = $scope.ticketMaster.blockId.id;
            usersService.getflatsByBlock(blockId).then(function (data) {
                $scope.flats = data;
                console.log(data);
            });
        }
        $scope.getStaffByDepchanged = function (departmentId1) {
            console.log($scope.ticketMaster.departmentId);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            var departmentId = $scope.ticketMaster.departmentId.id;
            ticketMastersService.getStaffByDepartment(departmentId).then(function (data) {
                    $scope.staffs = data;
                    console.log(data);
                });
        }
        $scope.editEvent = function () {
            if ($state.current.breadcrumb.text == "Edit") {
                ticketMastersService.getticketMasterbyId($stateParams.id).then(function (data) {
                    //$scope.getcategory();
                    console.log(data);
                    $scope.ticketMaster=data ;
                    $scope.ticketMaster.appartmentId=data.appartment ;
                   // $scope.ticketMaster.bookingDate= moment(data.appartment).format("YYYY-MM-DD") ;
                    $scope.ticketMaster.flatId=data.flat ;
                    $scope.ticketMaster.staffId=data.staff ;
                    $scope.ticketMaster.blockId=data.block ;
                    $scope.ticketMaster.departmentId=data.department ;
                    console.log( data.department) ;
                    // $scope.ticketMaster.userId=data.user ;
                    console.log(data.ticketStatus) ;
                    $scope.tempStatus = data.ticketStatus[data.ticketStatus.length - 1 ].status
                    $scope.event.status=data.ticketStatus[data.ticketStatus.length -1 ].status ;
                    $scope.getAppartmentonchange() ;
                    $timeout(function(){
                        console.log(data.staff) ;
                        if(data.staff !=undefined){
                            if(data.staff !="") {
                                $scope.getStaffByDepchanged() ;
                            }   
                           
                        } 
                        $scope.getFlatchange();
                    },200);
                    console.log(data) ;
                    var openingSplitTime=data.bookingDate.split('T') ;
                    var optingSplit1= openingSplitTime[1].split(':') ;
                    $scope.openingTime =new Date(2018, 11, 24, Number(optingSplit1[0]), Number(optingSplit1[1]), 0, 0);
                    $scope.bidOpeningDate =moment(data.bookingDate).format("YYYY-MM-DD");
                    $scope.event.showStatus=true ;
                    $scope.bidOpeningDateDis=true ;
                    $scope.openingTimeDis = true ;
                });
            }
        }
        $scope.editEvent();
        $scope.getBlocksOnChange = function (blockId) {
            var blockid = $scope.users.blockId.id;
            console.log(blockid);
            usersService.getFlatbyBlocks(blockid).then(function (data) {
                $scope.flats = data;
            });
        }
        // End Image 
        $scope.save = function (merchant) {
            var error = 0;
            if (error == 0) {
                if ($state.current.breadcrumb.text == "Create") {
                    $scope.ticketMaster.ticketStatus =[{
                        "status": 1001,
                        "timestamp": $scope.bidOpeningDate+'T'+moment($scope.openingTime).format('HH:mm')+':00.000Z' ,
                        "adminId":  $cookieStore.get("loginAccess").userId,
                        "name":  $cookieStore.get("loginAccess").user.username
                    }] ;
                    $scope.ticketMaster.appartmentId = $scope.ticketMaster.appartmentId.id ;
                    $scope.ticketMaster.blockId = $scope.ticketMaster.blockId.id ;
                    if( $scope.ticketMaster.departmentId !=undefined){
                        $scope.ticketMaster.departmentId = $scope.ticketMaster.departmentId.id ;
                    }else{
                        $scope.ticketMaster.departmentId ="" ;
                    }
                    $scope.ticketMaster.flatId = $scope.ticketMaster.flatId.id ;
                    if( $scope.ticketMaster.staffId !=undefined){
                        $scope.ticketMaster.staffId = $scope.ticketMaster.staffId.id ;
                    }else{
                        $scope.ticketMaster.staffId ="" ;
                    }
                    $scope.ticketMaster.bookingDate = $scope.bidOpeningDate+'T'+moment($scope.openingTime).format('HH:mm')+':00.000Z' ;
                    ticketMastersService.createticketMasters($scope.ticketMaster).then(function (data) {
                            $state.go('ticketMaster');
                            toaster.pop({
                                type: 'success',
                                title: 'ticket Created Successfully',
                                showCloseButton: true
                            });
                        })
                } else {
                    var galImages = [];
                    if($scope.event.status == 1003){
                        if( $scope.ticketMaster.departmentId ==undefined || $scope.ticketMaster.departmentId == "" ){
                            alert("select department") ;

                            error++ ;
                              return false ;
                        }

                        if( $scope.ticketMaster.staffId ==undefined || $scope.ticketMaster.staffId == "" ){
                            
                            alert("select staff") ;
                            error++ ;
                              return false ;
                        }

                    }
                    
                    if(error ==0){

                    $scope.ticketMaster.appartmentId = $scope.ticketMaster.appartmentId.id ;
                    $scope.ticketMaster.flatId = $scope.ticketMaster.flatId.id ;
                    if( $scope.ticketMaster.staffId !=undefined){
                        $scope.ticketMaster.staffId = $scope.ticketMaster.staffId.id ;
                    }else{
                        $scope.ticketMaster.staffId ="" ;
                    }

                    $scope.ticketMaster.blockId = $scope.ticketMaster.blockId.id ;
                    if( $scope.ticketMaster.departmentId !=undefined){
                        $scope.ticketMaster.departmentId = $scope.ticketMaster.departmentId.id ;
                    }else{
                        $scope.ticketMaster.departmentId ="" ;
                    }
                    $scope.ticketMaster.bookingDate = $scope.bidOpeningDate+'T'+moment($scope.openingTime).format('HH:mm')+':00.000Z' ;
                    delete $scope.ticketMaster.appartment ;
                    delete $scope.ticketMaster.flat ;
                    delete $scope.ticketMaster.staff ;
                    delete $scope.ticketMaster.block ;
                    delete $scope.ticketMaster.department ;
                    
                    if($scope.tempStatus != $scope.status){
                        $scope.ticketMaster.ticketStatus.push({
                            "status": $scope.event.status,
                            "timestamp": new Date().toISOString(),
                            "adminId":  $cookieStore.get("loginAccess").userId,
                            "name":  $cookieStore.get("loginAccess").user.username
                        }) ;
                    }
                   
                    
                    ticketMastersService.updateticketMasterById($scope.ticketMaster).then(function (data) {
                        $state.go('ticketMaster');
                        toaster.pop({
                            type: 'success',
                            title: 'ticket  Updated Successfully',
                            showCloseButton: true
                        });
                    })

                    }
                    

                    
                }
            }
        }
    }]);