'use strict';

angular.module('inspinia')
    .controller('billsCreateCtrl', ['$scope', '$state', 'NgMap', 'toaster', '$timeout', '$stateParams', '$rootScope', '$uibModal', '$log', 'FileUploader', 'configurationService', '$controller', 'billService','flatService', function ($scope, $state, NgMap, toaster, $timeout, $stateParams, $rootScope, $uibModal, $log, FileUploader, configurationService, $controller, billService,flatService) {
        $scope.startpointMarker = 'Hyderabad IN';
        $scope.appartment = {};
        $scope.imgobj = [];
        var polygonInstance;
        var polygonData;
        var regionMap;
        var deliveryMap;
        var pos = {};
        $scope.bill = {};
        var temp = [];
        $scope.regEx = /^[0-9]{10,10}$/;
        var fileurl = configurationService.baseUrl();
        console.log($state.current.breadcrumb.text) ;
        $scope.paymentStatusList=[
            {id:"1000",name:"Unpaid"},
            {id:"1001",name:"Paid"},
            {id:"1002",name:"Partially Paid"}
        ];
        $scope.genderList=[
            {name: "Select Gender", id : "Select Gender"},
            {name: "Male", id : "male"},
            {name: "Female", id : "female"}
        ];
        $scope.bill.gender ="Select Gender" ;
        // Map control //
        $scope.getCurrentLocation = function () {
            $scope.pos = this.getPosition();
            // edfi console.log($scope.pos);
            // $scope.appartment.location = {
            //     "lat": $scope.pos.lat(),
            //     "lng": $scope.pos.lng()
            // }
        }
        $scope.getPositionsMap = function (e) {
            $scope.pos = e.latLng;
            $scope.startpointMarker = [e.latLng.lat(), e.latLng.lng()];
        }
        $scope.removeImg = function (index) {
            $scope.users.logo = "";
        }
        $scope.getAppartmentonchange = function (appartmentId) {
            console.log($scope.bill.appartmentId);
              //console.log($scope.flat.appartmentId.id);
             // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            var appartmentid = $scope.bill.appartmentId.id;
            flatService.getBlocksbyAppartment(appartmentid).then(function (data) {
                $scope.blocks = data;
                console.log(data);
            });
            flatService.getDepartmentbyAppartment(appartmentid).then(function (data) {
                $scope.departmentList = data;
                console.log(data);
            });
            flatService.getVendorbyAppartment(appartmentid).then(function (data) {
                $scope.vendorList = data;
                console.log(data);
            });
        }
      //  console.log($stateParams.id);
        // Edit member api start here
        $scope.getBlocks = function () {
            if ($state.current.breadcrumb.text == "Edit") {
              //  console.log($stateParams.id)
              billService.getvendorbyId($stateParams.id).then(function (data) {
                    $scope.bill = data;
                    $scope.bill.appartmentId=data.appartment ;
                    $scope.bill.blockId =data.block ;
                    $scope.bill.departmentId =data.department ;
                    $scope.bill.vendorId =data.vendor ;
                    $scope.DPhotogetImage = true;
                    $scope.getAppartmentonchange() ;
                    var openingSplitTime=data.billDate.split('T') ;
                    var optingSplit1= openingSplitTime[1].split(':') ;
                    $scope.openingTime =new Date(2018, 11, 24, Number(optingSplit1[0]), Number(optingSplit1[1]), 0, 0);
                    $scope.bidOpeningDate =moment(data.billDate).format("YYYY-MM-DD");
                    var closeingSplitTime=data.dueDate.split('T') ;
                    var optingSplit2= closeingSplitTime[1].split(':') ;
                    $scope.closeingTime =new Date(2018, 11, 24, Number(optingSplit2[0]), Number(optingSplit2[1]), 0, 0);
                    $scope.bidCloseingDate =moment(data.dueDate).format("YYYY-MM-DD");
                    $scope.hideStatus=true ;
                });
            }
        }
        $scope.getBlocks();
        $scope.getAppartment = function () {
            //console.log($scope.users.appartmentId);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            // var appartmentid = $scope.users.appartmentId.id;
            billService.getAppartments().then(function (data) {
                $scope.appartments = data;
              //  console.log(data);
            });
        }
        $scope.getAppartment();
        // Edit member api end here
        // image upload start here
        $scope.baseurlimg = fileurl;
        // Driver address photo start Here
        $scope.driver_Photograph = function () {
            var img_div = angular.element(document.querySelector('#driver_Photograph'));
            img_div.addClass('remove_img');
        }
        var driverPhoto = $scope.driverPhoto = new FileUploader({
            scope: $scope,
            url: fileurl + '/containers/users/upload',
            formData: [
                { key: 'value' }
            ]
        });
        driverPhoto.onSuccessItem = function (item, response, status, headers) {
            $scope.driverAddPhoto = response;
            if ($scope.driverAddPhoto.result.files.file[0].name == undefined) {
                toastr.warning('Error : Problem in upload image');
            } else {
                $scope.bill.image = '/containers/users/download/' + $scope.driverAddPhoto.result.files.file[0].name;
                $scope.DPhotogetImage = true;
            }
        };
        // image upload end here
        // save / update api start here
        $scope.save = function (model) {
            var error = 0;
            if (error == 0) {
                if ($state.current.breadcrumb.text == "Create") {
                    $scope.bill.appartmentId=$scope.bill.appartmentId.id ;
                    $scope.bill.blockId =$scope.bill.blockId.id ;
                    $scope.bill.status = 1000 ;
                    $scope.bill.departmentId =$scope.bill.departmentId.id ;
                    $scope.bill.vendorId =$scope.bill.vendorId.id ;
                    $scope.bill.billDate = $scope.bidOpeningDate+'T'+moment($scope.openingTime).format('HH:mm')+':00.000Z' ;
                    $scope.bill.dueDate = $scope.bidOpeningDate+'T'+moment($scope.closeingTime).format('HH:mm')+':00.000Z' ;
                    billService.createStaffs($scope.bill).then(function (data) {
                        console.log(data);
                        $state.go('bills');
                        toaster.pop({
                            type: 'success',
                            title: 'Flat Created Successfully',
                            showCloseButton: true
                        });
                    })
                } else {
                    $scope.bill.appartmentId=$scope.bill.appartmentId.id ;
                    $scope.bill.blockId =$scope.bill.blockId.id ;
                    $scope.bill.departmentId =$scope.bill.departmentId.id ;
                    $scope.bill.vendorId =$scope.bill.vendorId.id ;
                    $scope.bill.billDate = $scope.bidOpeningDate+'T'+moment($scope.openingTime).format('HH:mm')+':00.000Z' ;
                    $scope.bill.dueDate = $scope.bidOpeningDate+'T'+moment($scope.closeingTime).format('HH:mm')+':00.000Z' ;
                    delete $scope.bill.appartment  ;
                    delete $scope.bill.department  ;
                    delete $scope.bill.block  ;
                    delete $scope.bill.vendor  ;
                    billService.updateStaffs($scope.bill).then(function (data) {
                        $state.go('bills');
                        toaster.pop({
                            type: 'success',
                            title: 'Flat Updated Successfully',
                            showCloseButton: true
                        });
                    })
                }
            }
        }
    }]);