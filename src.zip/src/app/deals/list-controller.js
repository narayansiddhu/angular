'use strict';

angular.module('inspinia')
    .controller('dealsListCtrl', function ($scope, $state, dealService, toaster, $stateParams) {
        var vm = this;

        // get user list api start here

        $scope.getDealsList = function () {
            dealService.getList().then(function (data) {

                $scope.deals = data;
                // console.log(data);
            });
        }
        $scope.getDealsList();

        // get user list api end here

        /********************Excel start  ***********************/
        // $scope.exportUsers = function () {
        //     alasql('SELECT * INTO XLSX("users.xlsx",{headers:true}) \
        //             FROM HTML("#users",{headers:true})');
        // };
        /********************Excel end  ***********************/

        // Delete user api start here
        $scope.delete = function (id) {
            dealService.deleteDeals(id).then(function (data) {
                if (data.result.count == 1) {
                    toaster.success('Deals Successfully Deleted!');
                    dealService.getList().then(function (data) {
                        $scope.deals = data;
                    });
                } else {
                    toaster.warning('Unable to delete');
                }
            });
        }
        // Delete user api end here

        $scope.edit = function (id) {
            $state.go('deals.edit', {
                id: id
            });
        }
    });