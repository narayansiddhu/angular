'use strict';

angular.module('inspinia')
    .controller('vehicleListCtrl', function ($scope, $state, vehicleService, toaster, $stateParams) {
        var vm = this;

        // get user list api start here

        $scope.getVehicles = function () {
            vehicleService.getVehicles().then(function (vehicles) {
               
                $scope.listVehicles = vehicles;

            });
        }
        $scope.getVehicles();



        // Delete user api start here
        $scope.delete = function (id) {
            vehicleService.deleteVehicle(id).then(function (data) {
                if (data.count == 1) {
                    toaster.success('Vehicle Successfully Deleted!');
                    vehicleService.getVehicles().then(function (vehicles) {
                        $scope.listVehicles = vehicles;

                    });
                } else {
                    toaster.warning('Unable to delete');
                }
            });
        }
        // Delete user api end here

        $scope.edit = function (id) {
            $state.go('vehicle.edit', {
                id: id
            });
        }

    });