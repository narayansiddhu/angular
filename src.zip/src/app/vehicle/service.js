'use strict';

angular.module('inspinia').service('vehicleService', ['$q', '$http', 'configurationService', function ($q, $http, configurationService) {

    //returns a promise that resolves with customers if found, 
    //otherwise reject


    this.getList = function () {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/vehicles?filter[include]=appartment&filter[include]=flat').success(function (data) {
            // console.log(data);
            // console.log('#######');

            D.resolve(data);
        });
        return D.promise;
    }

    this.getVehicles = function () {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/vehicles?filter[include]=appartment&filter[include]=flat').success(function (data) {
            // console.log(data);
            // console.log('#######');

            D.resolve(data);
        });
        return D.promise;
    }
    this.getVechilebyId = function (id) {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/vehicles/' + id+'?filter[include]=appartment&filter[include]=flat').success(function (data) {
            // console.log(data);
            // console.log('#######');

            D.resolve(data);
        });
        return D.promise;
    }


    this.create = function (data) {
        // console.log(data);
        var D = $q.defer()
        $http.post(configurationService.baseUrl() + '/vehicles', data).then(function (data) {
            console.log(data)
            D.resolve(data);
        }, function (data) {
            D.reject(data);
        });
        return D.promise;
    }



    this.deleteVehicle = function (id) {
        var D = $q.defer()
        $http.delete(configurationService.baseUrl() + '/vehicles/' + id).success(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }
    this.update = function (data) {
        var D = $q.defer()
        $http.put(configurationService.baseUrl() + '/vehicles', data).success(function (data) {
            D.resolve(data);
        }).error(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }
}]);
