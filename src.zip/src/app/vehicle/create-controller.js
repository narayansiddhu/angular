'use strict';

angular.module('inspinia')
    .controller('vehicleCreateCtrl', function ($scope, $state, NgMap, toaster, $timeout, $stateParams, $rootScope, $uibModal, $log, FileUploader, configurationService, $controller, dealService, vehicleService,usersService) {

        $scope.category = {};
        $scope.category.img = '';
        $scope.showimage = true;
        $scope.regEx = /^[0-9]{10,10}$/;
        var fileurl = configurationService.baseUrl();
        $scope.vehicle={} ;
        $scope.deals_Photograph = function () {
            var img_div = angular.element(document.querySelector('#deals_Photograph'));
            img_div.addClass('remove_img');
        }
        $scope.vechiclesList=[{id:'Two wheeler', name : '2 wheeler'},{id:'Four wheeler', name : '4 wheeler'},{id:'', name : 'Please select Vechile Type'}] ;
        $scope.vehicle.vehicleType = "" ;
        $scope.getAppartment = function () {
            //console.log($scope.users.appartmentId);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            // var appartmentid = $scope.users.appartmentId.id;
            usersService.getAppartments().then(function (data) {
                $scope.appartments = data;
                console.log(data);
            });
        }
        $scope.getAppartment();

        $scope.getAppartmentonchange = function (appartmentId) {
            console.log($scope.vehicle.appartmentId);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            var appartmentid = $scope.vehicle.appartmentId.id;
            usersService.getFlatbyAppartment(appartmentid).then(function (data) {
                $scope.flats = data;
                console.log(data);
            });
        }
        $scope.removeImg = function (index) {
            $scope.category.img="" ;
           // console.log($scope.category.img) ;
           // $scope.category.img.splice(index, 1);
        //console.log($scope.deals.images) ;

        }

        $scope.getCategorybyId = function () {
            if ($state.current.breadcrumb.text == "Edit") {

                vehicleService.getVechilebyId($stateParams.id).then(function (data) {
                    //Success code
                    console.log(data) ;
                    $scope.vehicle = data;
                    $scope.vehicle.appartmentId =data.appartment ;
                    $scope.vehicle.flatId =data.flat ;
                    $scope.getAppartment();
                    $scope.getAppartmentonchange() ;
                    $scope.DPhotogetImage = true;
                    $scope.baseurlimg = fileurl;
                    $scope.DPhotogetImage = true;
                });
            }
        }
        $scope.getCategorybyId();

        //get cat
        $scope.getcategory = function () {
            vehicleService.getVehicles().then(function (vehicles) {

                //console.log(merchants.result.list);
                $scope.listVehicles = vehicles;
            });
        }
        $scope.getcategory();







        // Edit member api end here
        // image upload start here
        $scope.baseurlimg = fileurl;
        // Driver address photo start Here
        $scope.driver_Photograph = function () {
            var img_div = angular.element(document.querySelector('#driver_Photograph'));
            img_div.addClass('remove_img');
        }
        var driverPhoto = $scope.driverPhoto = new FileUploader({
            scope: $scope,
            url: fileurl + '/containers/users/upload',
            formData: [
                { key: 'value' }
            ]
        });
        driverPhoto.onSuccessItem = function (item, response, status, headers) {
            $scope.driverAddPhoto = response;
            if ($scope.driverAddPhoto.result.files.file[0].name == undefined) {
                toastr.warning('Error : Problem in upload image');
            } else {
                $scope.vehicle.image = '/containers/users/download/' + $scope.driverAddPhoto.result.files.file[0].name;
                $scope.DPhotogetImage = true;
            }
        };
        // image upload end here

        // save / update api start here
        $scope.save = function (category) {

            var error = 0;


            if (error == 0) {
                if ($state.current.breadcrumb.text == "Create") {
                    $scope.vehicle.appartmentId=$scope.vehicle.appartmentId.id ;
                    $scope.vehicle.flatId =$scope.vehicle.flatId.id ;

                    vehicleService.create($scope.vehicle).then(function (data) {
                        $state.go('vehicle');
                        toaster.pop({
                            type: 'success',
                            title: 'vehicle Created Successfully',
                            showCloseButton: true
                        });
                    })
                } else {

                    var galImages = [];
                    $scope.vehicle.appartmentId=$scope.vehicle.appartmentId.id ;
                    $scope.vehicle.flatId =$scope.vehicle.flatId.id ;

                    delete $scope.vehicle.appartment ;
                    delete $scope.vehicle.flat ;

                    vehicleService.update($scope.vehicle).then(function (data) {
                        $state.go('vehicle');
                        toaster.pop({
                            type: 'success',
                            title: 'vehicle Updated Successfully',
                            showCloseButton: true
                        });
                    })
                }
            }
        }
    });