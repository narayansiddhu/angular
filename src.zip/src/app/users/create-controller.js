'use strict';

angular.module('inspinia')
    .controller('usersCreateCtrl', ['$scope', '$state', 'NgMap', 'toaster', '$timeout', '$stateParams', '$rootScope', '$uibModal', '$log', 'FileUploader', 'configurationService', '$controller', 'usersService', function ($scope, $state, NgMap, toaster, $timeout, $stateParams, $rootScope, $uibModal, $log, FileUploader, configurationService, $controller, usersService) {
        var polygonInstance;
        var polygonData;
        var regionMap;
        var deliveryMap;
        $scope.merchantModel = {};
        $scope.merchantModel.address = {};
        $scope.event = {};
        $scope.showimage = true;
        $scope.imgobj = [];
        $scope.regEx = /^[0-9]{10,10}$/;
        $scope.users = {};
        $scope.initialHide = false;
        var temp = [];
        var getCatName = {};
        $scope.tables = [{ id: 1, description: "Front" }, { id: 2, description: "Back" }];
        var fileurl = configurationService.baseUrl();
        $scope.users.family = [{ relation: "Select Relation", name: "", mobileNo: "" }];
        $scope.roleList=[{name: "Owner" ,id : "Owner"},{name: "Tenant" ,id : "Tenant"},{name: "Select Role" ,id : "Select Role"}];
        $scope.relationList=[{name: "Father" ,id : "Father"},{name: "Mother" ,id : "Mother"},{name: "Spouse" ,id : "Spouse"},{name: "Daughter" ,id : "Daughter"},{name: "Son" ,id : "Son"},{name: "Brother" ,id : "Brother"},{name: "Sister" ,id : "Sister"},{name: "Other" ,id : "Other"},{name: "Select Relation" ,id : "Select Relation"}];
        $scope.users.role = "Select Role" ;
        // $scope.family.relation = "Select Relation" ;
        $scope.open1 = function (index, selected, size) {
            NgMap.getMap('billingmap').then(function (map) {
                regionMap = map;
                google.maps.event.trigger(regionMap, 'resize');
            });
            //  $scope.searchArea = "Burlington";
            $scope.Mapindex = index;
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: 'app/users/mapTemplate.html',
                controller: 'wareHouseMapCtrl',
                size: size,

            });

            modalInstance.result.then(function (selectedItem) {
                $rootScope.pmapLatLngValues = selectedItem;
                $scope.selectedMap = selectedItem;
                latlngAddress($scope.selectedMap.data);
                $scope.merchantModel.address = selectedItem.message;
            }, function () {
                $log.info('Modal dismissed at: ' + new Date());
            });
        };
   

        $scope.addFamily = function (family) {


            //alert("addFamily")
            // $scope.finalAmount = "";
            $scope.users.family.push({ relation: "Select Relation", name: "", mobileNo: "" });
        };
        //  $scope.addFamily();

        $scope.removeFamily = function (index) {
            if ($scope.users.family.length) {
                $scope.users.family.splice(index, 1);
            }
        }


        // $scope.getUsersData = function () {
        //     usersService.getUsers().then(function (data) {

        //         console.log(data);
        //         $scope.users = data;
        //     });
        // }


        function latlngAddress(data) {
            console.log(data);
            _.each(data[0].address_components, function (component) {
                _.each(component.types, function (type) {

                    if (type === 'sublocality_level_2') {
                        $scope.merchantModel.address.street = component.long_name;

                    }
                    if (type === 'sublocality_level_1') {
                        $scope.merchantModel.address.area = component.long_name;
                    }
                    if (type === 'point_of_interest') {
                        $scope.merchantModel.address.plotNo = component.long_name;
                    }

                    if (type === 'administrative_area_level_1') {
                        $scope.merchantModel.address.city = component.long_name;
                    }
                    if (type === 'administrative_area_level_2') {
                        $scope.merchantModel.address.state = component.long_name;
                    }
                    if (type === 'postal_code') {
                        $scope.merchantModel.address.pincode = Number(component.long_name);
                    }
                    if (type === 'country') {
                        $scope.merchantModel.address.country = component.long_name;
                    }
                })
            })
        }
        $scope.removeImg = function (index) {
            $scope.users.logo = "";

        }
        // Edit member api start here
        // $scope.getcategory = function (category) {
        //     dealService.getCategory(category).then(function (category) {
        //         $scope.listCategory = category.result.list;
        //         console.log(category.result);
        //         $scope.showDropDown = false;
        //         $scope.showMapBtn = true;

        //     });
        // }
        // $scope.getcategory();
        $scope.editEvent = function () {
            if ($state.current.breadcrumb.text == "Edit") {
                usersService.getUserById($stateParams.id).then(function (data) {
                    //$scope.getcategory();
                    console.log(data) ;
                    $scope.users = data ;
                    console.log($scope.users.appartmentId) ;
                    $scope.users.appartmentId =data.appartment ;
                    $scope.users.blockId =data.block ;
                    $scope.users.flatId =data.flat ;
                    $scope.getAppartmentonchange($scope.users.appartmentId) ;
                    $scope.getFlatchange($scope.users.blockId) ;
                });
            }
        }
        $scope.editEvent();
        // Edit member api end here
        // Logo Image upload 
        $scope.getAppartmentonchange = function (appartmentId) {
            console.log($scope.users.appartmentId);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            var appartmentid = $scope.users.appartmentId.id;
            usersService.getBlocksbyAppartment(appartmentid).then(function (data) {

                $scope.blocks = data;
                console.log(data);
            });
        }

        $scope.getFlatchange = function (blockId) {
            console.log($scope.users.blockId);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            var blockId = $scope.users.blockId.id;
            usersService.getflatsByBlock(blockId).then(function (data) {
                $scope.flats = data;
                console.log(data);
            });
        }
        $scope.getAppartment = function () {
            //console.log($scope.users.appartmentId);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            // var appartmentid = $scope.users.appartmentId.id;
            usersService.getAppartments().then(function (data) {
                $scope.appartments = data;
                console.log(data);
            });
        }
        $scope.getAppartment();

        $scope.getBlocksOnChange = function (blockId) {
           // console.log($scope.users.blockId.id);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            var blockid = $scope.users.blockId.id;
            console.log(blockid);
            usersService.getFlatbyBlocks(blockid).then(function (data) {

                $scope.flats = data;
              //  console.log(data);
            });
        }

        $scope.baseurlimg = fileurl;
        $scope.deals_Photograph = function () {
            var img_div = angular.element(document.querySelector('#deals_Photograph'));
            img_div.addClass('remove_img');
        }
        var dealPhoto = $scope.dealPhoto = new FileUploader({
            scope: $scope,
            url: fileurl + '/containers/images/upload',
            formData: [
                { key: 'value' }
            ]
        });
        dealPhoto.onSuccessItem = function (item, response, status, headers) {
            //  alert(item);
            $scope.dealAddPhoto = response;
            if ($scope.dealAddPhoto.result.result.files.file[0].name == undefined) {
                toastr.warning('Error : Problem in upload image');
            } else {
                $scope.driverAddress = '/containers/images/download/' + $scope.dealAddPhoto.result.result.files.file[0].name;
                $scope.merchant.logo = '/containers/images/download/' + $scope.dealAddPhoto.result.result.files.file[0].name;
                $scope.DPhotogetImage = true;
                $scope.showDropDown = false;
                $scope.removeImg = function (index) {
                    $scope.merchant.logo = "";
                }
            }
        };
        // End Image 
        $scope.save = function (merchant) {
            var error = 0;
            if (error == 0) {
                if ($state.current.breadcrumb.text == "Create") {
                            // merchant.address.location = {
                           //     "lat": $rootScope.pmapLatLngValues.lat,
                          //     "lng": $rootScope.pmapLatLngValues.lng
                         // }
                      //var modifyaddres = [];
                     // modifyaddres.push(merchant.address);
                    //  merchant.address = modifyaddres;
                   //  console.log($scope.users.flatId.id)
                  $scope.users.appartmentId=$scope.users.appartmentId.id ;
                  $scope.users.blockId =$scope.users.blockId.id ;
                  $scope.users.flatId =$scope.users.flatId.id ;
                  $scope.users.password='123456' ;
                    usersService.createUser($scope.users).then(function (data) {
                        $state.go('users');
                        toaster.pop({
                            type: 'success',
                            title: 'User Created Successfully',
                            showCloseButton: true
                        });
                    })
                } else {
                    var galImages = [];

                    $scope.event.imageURL = galImages;
                    $scope.users.appartmentId=$scope.users.appartmentId.id ;
                    $scope.users.blockId =$scope.users.blockId.id ;
                    $scope.users.flatId =$scope.users.flatId.id ;

                    delete $scope.users.appartment ;
                    delete $scope.users.block ;
                    delete $scope.users.flat ;
                    usersService.updateUser($scope.users).then(function (data) {
                     
                        $state.go('users');
                        toaster.pop({
                            type: 'success',
                            title: 'User Updated Successfully',
                            showCloseButton: true
                        });
                    })
                }
            }
        }
    }]);