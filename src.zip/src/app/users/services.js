'use strict';

angular.module('inspinia').service('usersService', ['$q', '$http', 'configurationService', function ($q, $http, configurationService) {

    //returns a promise that resolves with customers if found,  
    //otherwise reject
    this.getUsers = function () {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/Users?filter[include]=appartment&filter[include]=block&filter[include]=flat').success(function (data) {

            D.resolve(data);
        });
        return D.promise;
    }
    this.getAppartments = function () {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/appartments').success(function (data) {
            // console.log(data)
            D.resolve(data);
        });
        return D.promise;
    }

    this.getBlocksbyAppartment = function (id) {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/appartments/' + id + '/blockData').success(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }

    
    this.getFlatbyAppartment = function (id) {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/appartments/' + id + '/flatData').success(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }

    
    this.getUserById = function (id) {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/users/' + id + '?filter[include]=appartment&filter[include]=block&filter[include]=flat').success(function (data) {

            D.resolve(data);
        });
        return D.promise;
    }
    this.getflatsByBlock = function (id) {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/blocks/' + id + '/flatData').success(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }
    this.getFlatbyBlocks = function (id) {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/blocks/' + id + '/flat').success(function (data) {
            console.log(data);
            D.resolve(data);
        });
        return D.promise;
    }
    this.createUser = function (data) {
        var D = $q.defer()
        $http.post(configurationService.baseUrl() + '/Users', data).then(function (data) {

            D.resolve(data);
        }, function (data) {
            D.reject(data);
        });
        return D.promise;
    }
    this.getEvent = function (id) {

        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/merchants/' + id).success(function (data) {
            // console.log(data);

            D.resolve(data);
        }).error(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }
    this.deleteMerchant = function (id) {
        var D = $q.defer()
        $http.delete(configurationService.baseUrl() + '/admins/deleteMerchant?merchantId=' + id).success(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }
    this.deleteUsers = function (id) {
        var D = $q.defer()
        $http.delete(configurationService.baseUrl() + '/users/' + id).success(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }
    
    this.updateUser = function (data) {
        var D = $q.defer()
        $http.put(configurationService.baseUrl() + '/users', data).success(function (data) {
            D.resolve(data);
        }).error(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }
}]);
