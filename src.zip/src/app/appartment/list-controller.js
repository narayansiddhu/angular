'use strict';

angular.module('inspinia')
    .controller('AppartmentListCtrl', function ($scope, $state, FileUploader, appartmentService, toaster, $stateParams) {
        var vm = this;

        // get user list api start here
        // $scope.exportToExcel = function () {
        //     var blob = new Blob([document.getElementById('tableToExport').innerHTML], {
        //         type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"
        //     });
        //     saveAs(blob, "UsersList.xls");
        // };
        $scope.getAppartmentList = function () {
            appartmentService.getList().then(function (data) {
                $scope.appartment = data;
                // console.log("$scope.appartment");
                //  console.log($scope.appartment);
            });
        }
        $scope.getAppartmentList();

        // get user list api end here

        /********************Excel start  ***********************/
        $scope.exportToExcel = function () {
            alasql('SELECT * INTO XLSX("myinquires.xlsx",{headers:true}) \
                    FROM HTML("#tableToExport",{headers:true})');
        };
        /********************Excel end  ***********************/

        // Delete user api start here
    
        $scope.delete = function (id) {
            appartmentService.deleteAppartmentId(id).then(function (data) {
                if (data.count == 1) {
                    toaster.success('Appartment Successfully Deleted!');
                    appartmentService.getList().then(function (data) {
                        $scope.appartment = data;
                    });
                } else {
                    toaster.warning('Unable to delete');
                }
            })
        }
        //   $scope.delete();
        // Delete user api end here

        $scope.edit = function (id) {
            $state.go('appartment.edit', {
                id: id
            });
        }
    });