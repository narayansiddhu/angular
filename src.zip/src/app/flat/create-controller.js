'use strict';

angular.module('inspinia')
    .controller('flatCreateCtrl', ['$scope', '$state', 'NgMap', 'toaster', '$timeout', '$stateParams', '$rootScope', '$uibModal', '$log', 'FileUploader', 'configurationService', '$controller', 'flatService', function ($scope, $state, NgMap, toaster, $timeout, $stateParams, $rootScope, $uibModal, $log, FileUploader, configurationService, $controller, flatService) {
        $scope.startpointMarker = 'Hyderabad IN';
  
        $scope.appartment = {};
       
        $scope.imgobj = [];
        var polygonInstance;
        var polygonData;
        var regionMap;
        var deliveryMap;
        var pos = {};
        $scope.flat = {};
        $scope.flat.image ="" ;
        
        var temp = [];
        $scope.regEx = /^[0-9]{10,10}$/;
        var fileurl = configurationService.baseUrl();
        $scope.baseurlimg=configurationService.baseUrl(); 

        // Map control //
        $scope.getCurrentLocation = function () {

            $scope.pos = this.getPosition();
            // edfi console.log($scope.pos);
            // $scope.appartment.location = {
            //     "lat": $scope.pos.lat(),
            //     "lng": $scope.pos.lng()

            // }
        }

        $scope.getPositionsMap = function (e) {

            $scope.pos = e.latLng;
            $scope.startpointMarker = [e.latLng.lat(), e.latLng.lng()];

        }
        $scope.removeImg = function (index) {
            $scope.users.logo = "";

        }
      //  console.log($stateParams.id);
        // Edit member api start here
        $scope.getFlatbyid = function () {
            if ($state.current.breadcrumb.text == "Edit") {
              //  console.log($stateParams.id)
                flatService.getFlatbyId($stateParams.id).then(function (data) {
                    $scope.flat = data;
                    $scope.flat.appartmentId=data.appartmentData ;
                    $scope.flat.blockId =data.blockData;
                    $scope.getAppartmentonchange(data.appartmentId); 
                   
                  //  $scope.update($scope.flat.appartmentId);
                   // console.log($scope.flat);
                  //  alert("enter");
                //    $scope.pos = data.location;
               //     $scope.pos = [$scope.pos.lat, $scope.pos.lng];
                    // $scope.member = data;
                    // $scope.member.dob = new Date(data.dob);
                    $scope.DPhotogetImage = true;
                });
            }
        }
        $scope.getFlatbyid();
        $scope.getAppartmentonchange = function (appartment) {
           console.log($scope.flat.appartmentId.id);
            //console.log($scope.flat.appartmentId.id);
           // console.log($scope.flat.appartmentId.id);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            
             
            if($scope.flat.appartmentId != undefined){
                var appartmentid = $scope.flat.appartmentId;
                flatService.getBlocksbyAppartment($scope.flat.appartmentId.id).then(function (data) {
                    $scope.blocks = data;
                    console.log(data);
                });
            }
          
        }
        
        $scope.getAppartment = function () {
            
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            // var appartmentid = $scope.users.appartmentId.id;
            flatService.getAppartments().then(function (data) {
                $scope.appartments = data;
              //  console.log(data);
            });
        }
        $scope.getAppartment();
        // Edit member api end here
        // image upload start here
        // var fileurl = configurationService.baseUrl();
        // $scope.baseurlimg = fileurl;
        // Driver address photo start Here
        $scope.driver_Photograph = function () {
            var img_div = angular.element(document.querySelector('#driver_Photograph'));
            img_div.addClass('remove_img');
        }
        var driverPhoto = $scope.driverPhoto = new FileUploader({
            scope: $scope,
            url: fileurl + '/containers/users/upload',
            formData: [
                { key: 'value' }
            ]
        });

        driverPhoto.onSuccessItem = function (item, response, status, headers) {
            $scope.driverAddPhoto = response;
            if ($scope.driverAddPhoto.result.files.file[0].name == undefined) {
                toastr.warning('Error : Problem in upload image');
            } else {
                $scope.flat.image = '/containers/users/download/' + $scope.driverAddPhoto.result.files.file[0].name;
                $scope.DPhotogetImage = true;
                
            }
        };
        // image upload end here

        // save / update api start here
        $scope.save = function (model) {
            var error = 0;
            // $scope.errorsinp = { "designation":"","username": "", "fullName": "", "dob": "", "mobileno": "", "landline": "", "address": "", "email": "", "password": "" };
            // if ($scope.member.username == undefined || $scope.member.username == '') {
            //     $scope.errorsinp.username = "Enter User Name";
            //     error++;
            // }
            // if ($scope.member.designation == undefined || $scope.member.designation == '') {
            //     $scope.errorsinp.designation = "Enter designation";
            //     error++;
            // }
            // if ($scope.member.fullName == undefined || $scope.member.fullName == '') {
            //     $scope.errorsinp.fullName = "Enter Full Name";
            //     error++;
            // }
            // if ($scope.member.dob == undefined || $scope.member.dob == '') {
            //     $scope.errorsinp.dob = "Enter DOB";
            //     error++;
            // }
            // if ($scope.member.mobileno == undefined || $scope.member.mobileno == '') {
            //     $scope.errorsinp.mobileno = "Enter Mobile No";
            //     error++;
            // }
            // if ($scope.member.landline == undefined || $scope.member.landline == '') {
            //     $scope.errorsinp.landline = "Enter landline no";
            //     error++;
            // }
            // if ($scope.member.address == undefined || $scope.member.address == '') {
            //     $scope.errorsinp.address = "Enter address";
            //     error++;
            // }
            // if ($scope.member.email == undefined || $scope.member.email == '') {
            //     $scope.errorsinp.email = "Enter email";
            //     error++;
            // }
            // if ($scope.member.password == undefined || $scope.member.password == '') {
            //     $scope.errorsinp.password = "Enter password";
            //     error++;
            // }
   

   
            if (error == 0) {
                if ($state.current.breadcrumb.text == "Create") {
                    console.log($scope.flat);
                    $scope.flat.appartmentId=$scope.flat.appartmentId.id ;
                    $scope.flat.blockId.id =$scope.flat.blockId.id ;
                    flatService.createFlat($scope.flat).then(function (data) {
                        console.log(data);
                        $state.go('flat');
                        toaster.pop({
                            type: 'success',
                            title: 'Flat Created Successfully',
                            showCloseButton: true
                        });
                    })
                } else {


                    $scope.flat.appartmentId=$scope.flat.appartmentId.id ;
                    $scope.flat.blockId =$scope.flat.blockId.id ;
                    delete  $scope.flat.appartmentData;
                    delete  $scope.flat.blockData ;
                    flatService.updateFlat($scope.flat).then(function (data) {

                        $state.go('flat');
                        toaster.pop({
                            type: 'success',
                            title: 'Flat Updated Successfully',
                            showCloseButton: true
                        });
                    })
                }
            }
        }
    }]);