'use strict';

angular.module('inspinia')
    .controller('flatListCtrl', function ($scope, $state, FileUploader, flatService, toaster, $stateParams) {
        var vm = this;

        // get user list api start here
        // $scope.exportToExcel = function () {
        //     var blob = new Blob([document.getElementById('tableToExport').innerHTML], {
        //         type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"
        //     });
        //     saveAs(blob, "UsersList.xls");
        // };
        $scope.getflatList = function () {
            flatService.getList().then(function (data) {
                console.log(data) ;
                $scope.flats = data;
              //   console.log($scope.flats);
                //  console.log($scope.appartment);
            });
        }
        $scope.getflatList();

        // get user list api end here

        /********************Excel start  ***********************/
        $scope.exportToExcel = function () {
            alasql('SELECT * INTO XLSX("myinquires.xlsx",{headers:true}) \
                    FROM HTML("#tableToExport",{headers:true})');
        };
        /********************Excel end  ***********************/

        // Delete user api start here
    
        $scope.delete = function (id) {
            flatService.deleteflatId(id).then(function (data) {
                if (data.count == 1) {
                    toaster.success('Flat Successfully Deleted!');
                    flatService.getList().then(function (data) {
                        $scope.flats = data;
                    });
                } else {
                    toaster.warning('Unable to delete');
                }
            })
        }
        //   $scope.delete();
        // Delete user api end here

        $scope.edit = function (id) {
            $state.go('flat.edit', {
                id: id
            });
        }
    });