'use strict';

angular.module('inspinia').service('flatService', ['$q', '$http', 'configurationService', function ($q, $http, configurationService) {

    //returns a promise that resolves with customers if found, 
    //otherwise reject


    this.getList = function () {
        var D = $q.defer()
        //http://52.220.190.223:2020/api/flats?filter[include]=appartment&filter[include]=block
        $http.get(configurationService.baseUrl() + '/flats?filter[include]=appartmentData&filter[include]=blockData').success(function (data) {
           // console.log(data)
            D.resolve(data);
        });
        return D.promise;
    }

    this.getAppartments = function () {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/appartments').success(function (data) {
            // console.log(data)
            D.resolve(data);
        });
        return D.promise;
    }

    this.getBlocksbyAppartment = function (id) {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/appartments/' + id + '/blockdata').success(function (data) {
            //console.info("service Data",data);
            D.resolve(data);
        });
        return D.promise;
    }

    this.getDepartmentbyAppartment = function (id) {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/appartments/' + id + '/departmentData').success(function (data) {
            //console.info("service Data",data);
            D.resolve(data);
        });
        return D.promise;
    }

    this.getVendorbyAppartment = function (id) {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/appartments/' + id + '/vendor').success(function (data) {
            //console.info("service Data",data);
            D.resolve(data);
        });
        return D.promise;
    }

    
    this.createFlat = function (data) {
        var D = $q.defer()
        $http.post(configurationService.baseUrl() + '/flats', data).then(function (data) {
            D.resolve(data);
        }, function (data) {
            D.reject(data);
        });
        return D.promise;
    }

    this.getFlatbyId = function (id) {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/flats/' + id+ '/?filter[include]=appartmentData&filter[include]=blockData').success(function (data) {
           
            D.resolve(data);
        }).error(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }
    this.deleteflatId = function (id) {
        var D = $q.defer()
        $http.delete(configurationService.baseUrl() + '/flats/' + id).success(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }
    this.updateFlat = function (data) {
        var D = $q.defer()
        $http.put(configurationService.baseUrl() + '/flats', data).success(function (data) {
            D.resolve(data);
        }).error(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }
}]);
