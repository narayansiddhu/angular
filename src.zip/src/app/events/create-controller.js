'use strict';

angular.module('inspinia')
    .controller('eventsCreateCtrl', ['$scope', '$state', 'NgMap', 'toaster', '$timeout', '$stateParams', '$rootScope', '$uibModal', '$log', 'FileUploader', 'configurationService', '$controller', 'eventService','flatService', function ($scope, $state, NgMap, toaster, $timeout, $stateParams, $rootScope, $uibModal, $log, FileUploader, configurationService, $controller, eventService,flatService) {
        $scope.startpointMarker = 'Hyderabad IN';
        $scope.appartment = {};
        $scope.imgobj = [];
        var polygonInstance;
        var polygonData;
        var regionMap;
        var deliveryMap;
        var pos = {};
        
        $scope.vendar = {};
        var temp = [];
        $scope.regEx = /^[0-9]{10,10}$/;
        var fileurl = configurationService.baseUrl();
        console.log($state.current.breadcrumb.text) ;
        $scope.genderList=[
            {name: "Select Gender", id : "Select Gender"},
            {name: "Male", id : "male"},
            {name: "Female", id : "female"}
        ];
        $scope.vendar.gender ="Select Gender" ;
        // Map control //
        $scope.getCurrentLocation = function () {
            $scope.pos = this.getPosition();
            // edfi console.log($scope.pos);
            // $scope.appartment.location = {
            //     "lat": $scope.pos.lat(),
            //     "lng": $scope.pos.lng()
            // }
        }
        $scope.getPositionsMap = function (e) {
            $scope.pos = e.latLng;
            $scope.startpointMarker = [e.latLng.lat(), e.latLng.lng()];
        }
        $scope.removeImg = function (index) {
            $scope.users.logo = "";
        }
        $scope.getAppartmentonchange = function (appartmentId) {
            console.log($scope.vendar.appartmentId);
           // console.log($scope.flat.appartmentId.id);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            var appartmentid = $scope.vendar.appartmentId.id;
            flatService.getBlocksbyAppartment(appartmentid).then(function (data) {
                $scope.blocks = data;
                console.log(data);
            });
            flatService.getDepartmentbyAppartment(appartmentid).then(function (data) {
                $scope.departmentList = data;
                console.log(data);
            });
        }
      //  console.log($stateParams.id);
        // Edit member api start here
        $scope.getBlocks = function () {
            if ($state.current.breadcrumb.text == "Edit") {
              //  console.log($stateParams.id)
              eventService.getVendarbyId($stateParams.id).then(function (data) {
                    $scope.vendar = data;
                    $scope.vendar.appartmentId=data.appartment ;
                    $scope.vendar.blockId =data.block ;
                    $scope.vendar.departmentId =data.department ;
                    $scope.DPhotogetImage = true;
                    $scope.getAppartmentonchange() ;
                    var openingSplitTime=data.eventDate.split('T') ;
                    var optingSplit1= openingSplitTime[1].split(':') ;
                    $scope.openingTime =new Date(2018, 11, 24, Number(optingSplit1[0]), Number(optingSplit1[1]), 0, 0);
                    $scope.bidOpeningDate =moment(data.eventDate).format("YYYY-MM-DD");
                });
            }
        }
        $scope.getBlocks();
        $scope.getAppartment = function () {
            //console.log($scope.users.appartmentId);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            // var appartmentid = $scope.users.appartmentId.id;
            eventService.getAppartments().then(function (data) {
                $scope.appartments = data;
              //  console.log(data);
            });
        }
        $scope.getAppartment();
        // Edit member api end here
        // image upload start here
         $scope.baseurlimg = fileurl;
        // Driver address photo start Here
        $scope.driver_Photograph = function () {
            var img_div = angular.element(document.querySelector('#driver_Photograph'));
            img_div.addClass('remove_img');
        }
        var driverPhoto = $scope.driverPhoto = new FileUploader({
            scope: $scope,
            url: fileurl + '/containers/users/upload',
            formData: [
                { key: 'value' }
            ]
        });
        driverPhoto.onSuccessItem = function (item, response, status, headers) {
            $scope.driverAddPhoto = response;
            if ($scope.driverAddPhoto.result.files.file[0].name == undefined) {
                toastr.warning('Error : Problem in upload image');
            } else {
                $scope.vendar.image = '/containers/users/download/' + $scope.driverAddPhoto.result.files.file[0].name;
                $scope.DPhotogetImage = true;
            }
        };
        // image upload end here
        // save / update api start here
        $scope.save = function (model) {
            var error = 0;
     
            if (error == 0) {
                if ($state.current.breadcrumb.text == "Create") {
                    $scope.vendar.appartmentId=$scope.vendar.appartmentId.id ;
                    $scope.vendar.eventDate = $scope.bidOpeningDate+'T'+moment($scope.openingTime).format('HH:mm')+':00.000Z' ;
                    eventService.createVendar($scope.vendar).then(function (data) {
                        console.log(data);
                        $state.go('events');
                        toaster.pop({
                            type: 'success',
                            title: 'Event Created Successfully',
                            showCloseButton: true
                        });
                    })
                } else {
                    $scope.vendar.appartmentId=$scope.vendar.appartmentId.id ;
                    $scope.vendar.eventDate = $scope.bidOpeningDate+'T'+moment($scope.openingTime).format('HH:mm')+':00.000Z' ;
                    delete $scope.vendar.appartment  ;
                    // delete $scope.vendar.department  ;
                    // delete $scope.vendar.block  ;
                    eventService.updateVendar($scope.vendar).then(function (data) {
                        $state.go('events');
                        toaster.pop({
                            type: 'success',
                            title: 'Event Updated Successfully',
                            showCloseButton: true
                        });
                    })
                }
            }
        }
    }]);