'use strict';

angular.module('inspinia')
    .controller('eventsListCtrl', function ($scope, $state, FileUploader, eventService, toaster, $stateParams) {
        var vm = this;
        // get user list api start here
        // $scope.exportToExcel = function () {
        //     var blob = new Blob([document.getElementById('tableToExport').innerHTML], {
        //         type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"
        //     });
        //     saveAs(blob, "UsersList.xls");
        // };
        $scope.getstaffList = function () {
            eventService.getList().then(function (data) {
                $scope.vendars = data;
               // console.log($scope.flats);
                //  console.log($scope.appartment);
            });
        }
        $scope.getstaffList();
        // get user list api end here
        /********************Excel start  ***********************/
        $scope.exportToExcel = function () {
            alasql('SELECT * INTO XLSX("myinquires.xlsx",{headers:true}) \
                    FROM HTML("#tableToExport",{headers:true})');
        };
        /********************Excel end  ***********************/

        // Delete user api start here
    
        $scope.delete = function (id) {
            eventService.deleteVendar(id).then(function (data) {
                if (data.count == 1) {
                    eventService.getList().then(function (data) {
                        $scope.vendars = data;
                       // console.log($scope.flats);
                        //  console.log($scope.appartment);
                    });
                    toaster.success('Event Successfully Deleted!');
                     

                } else {
                    toaster.warning('Unable to delete');
                }
            })
        }
        //   $scope.delete();
        // Delete user api end here

        $scope.edit = function (id) {
            $state.go('events.edit', {
                id: id
            });
        }
    });