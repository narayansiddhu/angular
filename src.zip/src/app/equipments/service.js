'use strict';

angular.module('inspinia').service('equipmentService', ['$q', '$http', 'configurationService', function ($q, $http, configurationService) {

    //returns a promise that resolves with customers if found, 
    //otherwise reject


    this.getList = function () {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/equipments').success(function (data) {
            // console.log(data);
            // console.log('#######');

            D.resolve(data);
        });
        return D.promise;
    }
    this.getAppartments = function () {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/appartment').success(function (data) {
            // console.log(data)
            D.resolve(data);
        });
        return D.promise;
    }

    this.getEquipments = function () {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/equipments?filter[include]=appartment').success(function (data) {
            // console.log(data);
            // console.log('#######');

            D.resolve(data);
        });
        return D.promise;
    }
    this.getEqupById = function (id) {
        var D = $q.defer()
        $http.get(configurationService.baseUrl() + '/equipments/' + id+'?filter[include]=appartment&filter[include]=block').success(function (data) {
            // console.log(data);
            // console.log('#######');

            D.resolve(data);
        });
        return D.promise;
    }


    this.createEquipments = function (data) {
        // console.log(data);
        var D = $q.defer()
        $http.post(configurationService.baseUrl() + '/equipments', data).then(function (data) {
            console.log(data)
            D.resolve(data);
        }, function (data) {
            D.reject(data);
        });
        return D.promise;
    }



    this.deleteCategory = function (id) {
        var D = $q.defer()
        $http.delete(configurationService.baseUrl() + '/equipments/' + id).success(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }
    this.updateEquipments = function (data) {
        var D = $q.defer()
        $http.put(configurationService.baseUrl() + '/equipments', data).success(function (data) {
            D.resolve(data);
        }).error(function (data) {
            D.resolve(data);
        });
        return D.promise;
    }
}]);
