'use strict';

angular.module('inspinia')
    .controller('equipmentsListCtrl', function ($scope, $state, equipmentService, toaster, $stateParams) {
        var vm = this;

        // get user list api start here

        $scope.getEquipments = function () {
            equipmentService.getEquipments().then(function (data) {
               
                $scope.getEquipmentsList = data;

            });
        }
        $scope.getEquipments();



        // Delete user api start here
        $scope.delete = function (id) {
         
            equipmentService.deleteCategory(id).then(function (data) {
                if (data.count == 1) {
                    toaster.success('equipment Successfully Deleted!');
                    equipmentService.getEquipments().then(function (data) {
               
                        $scope.getEquipmentsList = data;
        
                    });
                } else {
                    toaster.warning('Unable to delete');
                }
            });
        }
        // Delete user api end here

        $scope.edit = function (id) {
            $state.go('equipments.edit', {
                id: id
            });
        }

    });