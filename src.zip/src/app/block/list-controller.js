'use strict';

angular.module('inspinia')
    .controller('blockListCtrl', function ($scope, $state, FileUploader, blockService, toaster, $stateParams) {
        var vm = this;

        // get user list api start here
        // $scope.exportToExcel = function () {
        //     var blob = new Blob([document.getElementById('tableToExport').innerHTML], {
        //         type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"
        //     });
        //     saveAs(blob, "UsersList.xls");
        // };
        $scope.getblockList = function () {
            blockService.getList().then(function (data) {
                console.log(data) ;
                $scope.blocks = data;
                // console.log("$scope.appartment");
                //  console.log($scope.appartment);
            });
        }
        $scope.getblockList();

        // get user list api end here

        /********************Excel start  ***********************/
        $scope.exportToExcel = function () {
            alasql('SELECT * INTO XLSX("myinquires.xlsx",{headers:true}) \
                    FROM HTML("#tableToExport",{headers:true})');
        };
        /********************Excel end  ***********************/

        // Delete user api start here
    
        $scope.delete = function (id) {
            blockService.deleteblockId(id).then(function (data) {
                if (data.count == 1) {
                    toaster.success('Block Successfully Deleted!');
                    blockService.getList().then(function (data) {
                        $scope.blocks = data;
                    });
                } else {
                    toaster.warning('Unable to delete');
                }
            })
        }
        //   $scope.delete();
        // Delete user api end here

        $scope.edit = function (id) {
            $state.go('block.edit', {
                id: id
            });
        }
    });