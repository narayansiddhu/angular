'use strict';

angular.module('inspinia')
    .controller('blockCreateCtrl', ['$scope', '$state', 'NgMap', 'toaster', '$timeout', '$stateParams', '$rootScope', '$uibModal', '$log', 'FileUploader', 'configurationService', '$controller', 'blockService', function ($scope, $state, NgMap, toaster, $timeout, $stateParams, $rootScope, $uibModal, $log, FileUploader, configurationService, $controller, blockService) {
        $scope.startpointMarker = 'Hyderabad IN';
        $scope.appartment = {};
        $scope.imgobj = [];
        var polygonInstance;
        var polygonData;
        var regionMap;
        var deliveryMap;
        var pos = {};
        var temp = [];
        $scope.regEx = /^[0-9]{10,10}$/;
        var fileurl = configurationService.baseUrl();

        // Map control //
        $scope.getCurrentLocation = function () {

            $scope.pos = this.getPosition();
            // edfi console.log($scope.pos);
            // $scope.appartment.location = {
            //     "lat": $scope.pos.lat(),
            //     "lng": $scope.pos.lng()

            // }
        }

        $scope.getPositionsMap = function (e) {

            $scope.pos = e.latLng;
            $scope.startpointMarker = [e.latLng.lat(), e.latLng.lng()];

        }
        $scope.removeImg = function (index) {
            $scope.users.logo = "";

        }
      //  console.log($stateParams.id);
        // Edit member api start here
        $scope.getBlocks = function () {
            if ($state.current.breadcrumb.text == "Edit") {
              //  console.log($stateParams.id)

                blockService.getBlockbyId($stateParams.id).then(function (data) {
                    console.log(data) ;
                    $scope.block = data;

                    
                    $scope.block.appartmentId = data.appartmentData ;
                    console.log(data.appartmentId) ;


                  //  alert("enter");
                //  $scope.pos = data.location;
               //   $scope.pos = [$scope.pos.lat, $scope.pos.lng];
                    // $scope.member = data;
                    // $scope.member.dob = new Date(data.dob);
                    // $scope.DPhotogetImage = true;
                });
            }
        }
        $scope.getBlocks();

        $scope.getAppartment = function () {
            //console.log($scope.users.appartmentId);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            // var appartmentid = $scope.users.appartmentId.id;
            blockService.getAppartments().then(function (data) {
                $scope.appartments = data;
              //  console.log(data);
            });
        }
        $scope.getAppartment();


        // Edit member api end here
        // image upload start here
        // var fileurl = configurationService.baseUrl();
        // $scope.baseurlimg = fileurl;

        // Driver address photo start Here
        $scope.driver_Photograph = function () {
            var img_div = angular.element(document.querySelector('#driver_Photograph'));
            img_div.addClass('remove_img');
        }

        var driverPhoto = $scope.driverPhoto = new FileUploader({
            scope: $scope,
            url: fileurl + '/containers/users/upload',
            formData: [
                { key: 'value' }
            ]
        });

        driverPhoto.onSuccessItem = function (item, response, status, headers) {
            $scope.driverAddPhoto = response;
            if ($scope.driverAddPhoto.result.files.file[0].name == undefined) {
                toastr.warning('Error : Problem in upload image');
            } else {
                $scope.driverAddress = '/containers/users/download/' + $scope.driverAddPhoto.result.files.file[0].name;
                $scope.DPhotogetImage = true;
                $scope.member.imageURL = $scope.driverAddress;
            }
        };
        // image upload end here

        // save / update api start here
        $scope.save = function (model) {
            var error = 0;
          
   
            if (error == 0) {
                if ($state.current.breadcrumb.text == "Create") {
                    $scope.block.appartmentId = $scope.block.appartmentId.id ;
                
                    
                    blockService.createBlock($scope.block).then(function (data) {
                        $state.go('block');
                        toaster.pop({
                            type: 'success',
                            title: 'Block Created Successfully',
                            showCloseButton: true
                        });
                    })
                } else {
                    $scope.block.appartmentId = $scope.block.appartmentId.id ;
                    blockService.updateBlocks($scope.block).then(function (data) {
                        $state.go('block');
                        toaster.pop({
                            type: 'success',
                            title: 'Block Updated Successfully',
                            showCloseButton: true
                        });
                    })
                }
            }
        }
    }]);