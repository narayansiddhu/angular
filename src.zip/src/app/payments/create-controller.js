'use strict';

angular.module('inspinia')
    .controller('paymentsCreateCtrl', ['$scope', '$state', 'NgMap', 'toaster', '$timeout', '$stateParams', '$rootScope', '$uibModal', '$log', 'FileUploader', 'configurationService', '$controller', 'paymentService','flatService', 'billService',function ($scope, $state, NgMap, toaster, $timeout, $stateParams, $rootScope, $uibModal, $log, FileUploader, configurationService, $controller, paymentService,flatService,billService) {
        $scope.payLoad={} ;   
        $scope.getLoad={} ;    
        $scope.BillPaytableView=false ;
        $scope.regEx = /^[0-9]{10,10}$/;
        var fileurl = configurationService.baseUrl();
        console.log($state.current.breadcrumb.text) ;
        $scope.paymentTypesList=[
            {name: "Select Paymen mode", id : ""},
            {name: "Cash", id : "cash"},
            {name: "Card", id : "card"}
        ];
        $scope.paymentStatusList=[
            {id:"1000",name:"Unpaid"},
            {id:"1001",name:"Paid"},
            {id:"1002",name:"Partially Paid"}
        ];
        $scope.appartmentId="" ;

        $scope.addMore=function(){
            $scope.payLoad.paymentMode.push({
                "paymentMode": "card",
                "amount": "",
                "paymentStatus": true,
                "transactionId": ""
              }) ;
        }
        $scope.removeEntry=function(index){
            if($scope.payLoad.paymentMode.length !=1){
                $scope.payLoad.paymentMode.splice(index,1) ;
            }
          
        }
        $scope.getAppartmentonchange = function (appartmentId) {
            console.log($scope.getLoad.appartmentId) ;
              // console.log($scope.flat.appartmentId.id);
             // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            $scope.billsList = [];
            $scope.paymentList = [];
            $scope.getLoad.vendorId={"name":"Please select","id":""} ;
            var appartmentid = $scope.getLoad.appartmentId.id;
            flatService.getBlocksbyAppartment(appartmentid).then(function (data) {
                $scope.blocks = data;
                console.log(data);
            });
            flatService.getVendorbyAppartment(appartmentid).then(function (data) {
                $scope.vendorList = data;
                console.log(data);
            });
        }
      
        $scope.getPaymentonchange = function (vendarId) {
            paymentService.getVendorbyBills(vendarId.id).then(function (data) {
                $scope.billsList = data;
                console.log(data);
            });
            paymentService.getVendorbyPayment(vendarId.id).then(function (data) {
                $scope.paymentList = data;
                console.log(data);
            });
        }
       
        $scope.getPaidAmount=function(data){
          
            //Loadash sum
            var output =  _.sumBy(data.paymentMode, function(o) { return Number(o.amount); });
            console.log(output);
            return output
          
        }
        $scope.getUnpaidAmount=function(data){
            console.log(data) ;
            //Loadash sum
            var output =  _.sumBy(data.paymentMode, function(o) { return Number(o.amount); });
            return Number(data.totalAmount) - output   ;
          
        }
        $scope.pay=function(bill,id){
            $scope.BillPaytableView=true ;
            paymentService.getBillbyPayment(id).then(function (data) {
                console.log(bill) ;
                if(data.length !=0){
                    $scope.methodHit ="update" ;
                    $scope.payLoad = data[0] ;
                }else{
                    $scope.methodHit ="create" ;
                    $scope.payLoad =   {
                        "description": "",
                        "totalAmount": bill.totalAmount,
                        "recieptNo": "",
                        "paymentMode": [
                          {
                            "paymentMode": "card",
                            "amount": "",
                            "paymentStatus": false,
                            "transactionId": ""
                          }
                        ],
                        "appartmentId": $scope.getLoad.appartmentId.id,
                        "vendorId": $scope.getLoad.vendorId.id,
                        "billId": bill.id,
                        "paymentDate": new Date().toISOString(),
                        "status" :"1000"
                      }
                }
            });
        }
        $scope.payClose=function(){
            $scope.BillPaytableView=false ;
        }
        $scope.getAppartment = function () {
            //console.log($scope.users.appartmentId);
            // $scope.appartments[index].getProductList = "";
            //  $scope.appartments[index].sub = [];
            // var appartmentid = $scope.users.appartmentId.id;
            paymentService.getAppartments().then(function (data) {
                $scope.appartments = data;
              //  console.log(data);
            });
        }
        $scope.getAppartment();
        // image upload end here
        // save / update api start here
        $scope.save = function (model) {
           //$scope.payLoad
            
           if($scope.methodHit == 'create'){
               console.log('create',$scope.payLoad);
                paymentService.createPayment($scope.payLoad).then(function (data) {
                    $scope.appartments = data;
                    //console.log(data);
                  
                    toaster.pop({
                        type: 'success',
                        title: 'payment  Successfully',
                        showCloseButton: true
                    });

                    var status={
                        status : $scope.payLoad.status,
                        id : $scope.payLoad.billId

                    }
                    billService.updateStaffs(status).then(function(){
                        //Update status
                    });
                });
                $scope.getPaymentonchange($scope.getLoad.vendorId) ;
                $scope.payClose();
           }else{
                console.log('Edit',$scope.payLoad);
                paymentService.updatePayment($scope.payLoad).then(function (data) {
                    $scope.appartments = data;
                    //console.log(data);
                    
                    toaster.pop({
                        type: 'success',
                        title: 'payment updated  Successfully',
                        showCloseButton: true
                    });
                    var status={
                        status : $scope.payLoad.status,
                        id : $scope.payLoad.billId
                    }
                    billService.updateStaffs(status).then(function(){
                        //Update status
                    });
                });
                $timeout(function(){
                    $scope.getPaymentonchange($scope.getLoad.vendorId) ;
                },200)
              
                $scope.payClose();
           }
        }
    }]);