'use strict';

angular.module('inspinia').service('configurationService', ['$q','$location', function($q,$location) {
    this.baseUrl = function() {
       	return "http://52.220.190.223:2020/api";                                                      
    }     
}]);      

